


#ifndef __COMMAND_INTERPRETER_H
#define __COMMAND_INTERPRETER_H


typedef struct{
	char const *cmd_name;
}




#endif