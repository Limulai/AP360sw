


#ifndef __DEBUG_H
#define __DEBUG_H


#define CMD_LINE_DEBUG 1
#define MY_DBG_ON 1
#define MY_DEBUG
#ifdef MY_DEBUG    
#define MY_DEBUGF(message) do{UARTprintf(message);} while(0)
//#define MY_DEBUGF(debug, message) do { \
//								if(((debug)&MY_DBG_ON)){UARTprintf(message);} \
//							 } while(0)    
#else      
#define MY_DEBUGF(message)      
#endif /* PLC_DEBUG */ 



#endif
							 
							 
							 
							 