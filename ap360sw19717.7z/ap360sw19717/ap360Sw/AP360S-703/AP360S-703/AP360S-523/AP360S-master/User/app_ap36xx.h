#ifndef __APP_AP36XX_H__
#define __APP_AP36XX_H__


#include <stm32f10x.h>

#define WATCH_DOG 1

/*=================================KEY ���================================================================================*/
#define KEY_RELEASE 1
#define KEY_PUSH    0
#define KEY_SHORT_TIME 3
#define KEY_2S_TIME    150
#define KEY_5S_TIME    250
#define KEY_10S_TIME   400
#define MAX_PRESS_TIME 1000

#define KEY_POWER_SHORT_BIT (1<<0)
#define KEY_POWER_2S_BIT (1<<1)
#define KEY_POWER_10S_BIT (1<<2)
#define KEY_POWER_LONG_BIT (1<<3)
#define KEY_BOOST_SHORT_BIT (1<<8)
#define KEY_BOOST_2S_BIT (1<<9)
#define KEY_BOOST_10S_BIT (1<<10)
#define KEY_BOOST_LONG_BIT (1<<11)
#define KEY_MODE_SHORT_BIT (1<<16)
#define KEY_MODE_2S_BIT (1<<17)
#define KEY_MODE_10S_BIT (1<<18)
#define KEY_MODE_LONG_BIT (1<<19)


typedef enum {
	KEY_IDLE = 0,
	KEY_SHORT_PRESS,
	KEY_2S_PRESS,
	KEY_10S_PRESS,
	KEY_LONG_PRESS,
}KeyType;	
uint8_t key_state(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin);




/*================================ADC Ӧ�ú���====================================================*/
#define TUNGSTEN_VOLT_LOWER_LIMIT 1.0f  //��˿��ѹӦ���ڴ˵�ѹ������Ϊ2.5V����
#define ALARM_VOLT_UPPER_LIMIT 1.002f
#define ALARM_VOLT_LOWER_LIMIT 0.13f
#define ALARM_VOLT_LOWER_LIMIT_FAN_LOW 0.1f
#define ALARM_SEMAPHORE 0x02
#define TUNGSTEN_A_BREAK 0X01
#define TUNGSTEN_B_BREAK 0X04
#define TUNGSTEN_AB_BREAK 0X05


uint8_t GetVoltAlarm_N_Adj(void);
uint8_t GetVoltTungsten_N_Adj(void);



/*=================================������====================================================*/
extern float g_temperature;
extern float g_humidity;
extern float g_pm25;
extern float g_pm10;
extern float g_ch2o;
#define SENSOR_BUFF_DEPTH 5
typedef struct{
	float circular_buff[SENSOR_BUFF_DEPTH];
	uint8_t circular_subscript;
}sensor_buff_t;

extern sensor_buff_t pm25_data;
extern sensor_buff_t ch2o_data;
void putin_sensor_buff(sensor_buff_t *sensor_buff, float data);
float SensorDataFilter(float *buff, uint8_t precision);
uint8_t GetPMState(void);/////

#define HUMIDITY_MAX 0.99f
#define PM25_ALARM_MAX 75.0f
#define CH2O_ALARM_MAX 0.15f
#define PM25_LOW 15.0f
#define PM25_MID 35.0f
#define PM25_HIGH PM25_ALARM_MAX
#define PM25_VERYHIGH 115.0f



/*================================= ����=======================================================================*/
//#define CLAEN_TIME_MAX  336  //��ʾ�ۻ���CleanTimeResolution��������CleanTimeResolutionΪ1hour��CLEAN_TIME_MAXΪ336ʱ��Ϊ����ʱ����
//#define CLEAN_TIME_MAX_DEFAULT            336		//2��
#define CLEAN_TIME_MAX_DEFAULT            2016		//3����
#define CLEAN_TIME_RESOLUTION_DEFAULT	  3600//��λ��
//#define CLEAN_TIME_MAX_DEFAULT            100	//3����
//#define CLEAN_TIME_RESOLUTION_DEFAULT	  3600//��λ��
#define	BOOST_TIME_MAX_DEFAULT			  1200
#define BOOST_TIME_RESOLUTION_DEFAULT	  1   //��λ��
#define DRYING_TIME_MAX_DEFAULT			  1800
#define DRYING_TIME_RESOLUTION_DEFAULT	  1   //��λ��

extern uint16_t g_clean_time_max;
extern uint16_t g_clean_time_resolution;
extern uint16_t g_boost_time_max;
extern uint16_t g_boost_time_resolution;
extern uint16_t g_drying_time_max;
extern uint16_t g_drying_time_resolution;
extern uint8_t g_ala_enable;
extern uint8_t g_tun_enable;

#define CLEAN_TIME_HIGH  1
#define CLEAN_TIME_LOW   0
#define CLEAN_TIME_ADDR              0x00
#define CLEAN_TIME_MAX_ADDR          0X02
#define CLEAN_TIME_RESOLUTION_ADDR   0X04
#define BOOST_TIME_MAX_ADDR          0X06
#define BOOST_TIME_RESOLUTION_ADDR   0X08
#define DRYING_TIME_MAX_ADDR         0X0A
#define DRYING_TIME_RESOLUTION_ADDR  0X0C
#define ALA_ENABLE_ADDR              0X0E
#define TUN_ENABLE_ADDR              0X0F
#define MODE_FLAG                    0X10
extern uint8_t  g_clean_time[];
extern uint16_t g_drying_time;
extern uint16_t g_boost_time;

void watchdogInit(uint8_t timeoutS);
void watchdogFeed(void);
void GetLightDiode(void);
void AdjBrightness(void);
void HandlePM_InPoweroff(void);

/*=================================ϵͳģʽ  ======================================================*/
#define DRYING_TIME   1  //����ģʽ����ʱ������λ������; ��Χ��0-60
#define BOOST_TIME    10 //boost ģʽ����ʱ������λ����


extern uint8_t g_fault_code;
typedef enum
{
    MODE_NORMAL = 0,//normal
    MODE_DRYING = 1,//drying
    MODE_CLEAN = 2,//clean
    MODE_FAULT = 3,//fault
    MODE_POWEROFF = 4,//poweroff
	MODE_PAIR = 5,//
	MODE_TEST = 6,
    //STATUS_VALUE_MAX,
} MODE;
extern MODE g_SystemStatus;
typedef struct{
	uint16_t alarm_highVolt:1;
	uint16_t alarm_tungsten_a_broken:1;
	uint16_t alarm_tungsten_b_broken:1;
	uint16_t nodata_pm25_module:1;
	uint16_t nodata_ch2o_module:1;
	uint16_t nodata_hdc_module:1;
	uint16_t nodata_eeprom_module:1;
	uint16_t fan:1;
	uint16_t alarm_pm25_overRange:1;
	uint16_t alarm_ch2o_overRange:1;
	uint16_t reserve:6;
	
	uint8_t malfunction_code;
	
}malfunction_t;
#define DISCONNECTED 1
#define CONNECTED    0
extern malfunction_t g_malfunction;
void adj_malfunction(malfunction_t *malfunction);
typedef struct
{
	uint16_t            softap:1;               ///< ??WiFi?????SOFTAP????,???bool
	uint16_t            station:1;              ///< ??WiFi?????STATION????,???bool
	uint16_t            onboarding:1;           ///< ??WiFi?????????,???bool
	uint16_t            binding:1;              ///< ??WiFi?????????,???bool
	uint16_t            con_route:1;            ///< ??WiFi???????????,???bool
	uint16_t            con_m2m:1;              ///< ??WiFi?????m2m???,???bool
	uint16_t            reserve1:2;             ///< ?????
	uint16_t            rssi:3;                 ///< ?????????,?????
	uint16_t            app:1;                  ///< ??WiFi???APP??????,???bool
	uint16_t            test:1;                 ///< ??WiFi???????????,???bool
	uint16_t            reserve2:3;             ///< ?????
}wifi_status_t; 
extern wifi_status_t g_wifi_status;

void TimerSleepCounter(void);

///*================================= TASKs  =======================================================================*/
void TaskGizwits(void *parameter);
void TaskChangeSystemOutput(void *parameter);
void TaskSecurityDetect(void *parameter);
void TaskSecurity(void *parameter);
void TaskTungstenDetect(void *parameter);
void TaskAlarmDetect(void *parameter);
void TaskHumidity(void *parameter);
void TaskCountCleanTime(void *patameter);
void TaskCountBoostTime(void *parameter);
void TaskGetVoltDiodeAndAdj(void *parameter);
void TaskLedsBrightness(void * parameter);
void led_test(void * parameter);
void TaskBoostFlashing(void *parameter);
void TaskScanKeys(void *parameter);
void TaskTestKeys(void *parameter);
void task_humidity_handler(void *parameter);
void TaskGetCH2O(void *parameter);
void TaskGetPM(void *parameter);
void AIfunc(void);
void PM_disp(void);
void TaskAI(void *parameter);
void TaskPair(void *parameter);
void TaskDetectNetwork(void *parameter);


#endif
