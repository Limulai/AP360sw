#include "BSP_HDC1080.h"
#include "includes.h"


static uint8_t HDC_TIMEOUT_UserCallback(uint8_t ERROR_CODE);


uint8_t InitHDC1080(I2C_TypeDef * IICx){
	uint16_t setValue=0;
	uint16_t I2CTimeout ;
	setValue = (1<<12); /*������ʪ��һ���ȡģʽ���ֱ��ʶ�Ϊ14λ*/
	/* 1, Configure the acquisiton parameters in register 0x02*/
	I2C_GenerateSTART(IICx, ENABLE);	
	I2CTimeout = HDC1080_FLAG_TIMEOUT;   //�ȴ��źŲ�����
  while(!I2C_CheckEvent(IICx, I2C_EVENT_MASTER_MODE_SELECT)){  /* Test on EV5 and clear it */
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	
	I2C_Send7bitAddress(IICx, ADDRESS_HDC1080, I2C_Direction_Transmitter);
	I2CTimeout = HDC1080_FLAG_TIMEOUT;   //�ȴ����ͽ���
  while(!I2C_CheckEvent(IICx, I2C_EVENT_MASTER_BYTE_TRANSMITTED)){ 
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	
	I2C_SendData(IICx, ADDRESS_CONFIGURATION);
	I2CTimeout = HDC1080_FLAG_TIMEOUT;   //�ȴ����ͽ���
  while(!I2C_CheckEvent(IICx, I2C_EVENT_MASTER_BYTE_TRANSMITTED)){ 
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	
	I2C_SendData(IICx, (uint8_t)(setValue>>8));
	I2CTimeout = HDC1080_FLAG_TIMEOUT; //�ȴ����ͽ���  
  while(!I2C_CheckEvent(IICx, I2C_EVENT_MASTER_BYTE_TRANSMITTED)){ 
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	
	I2C_SendData(IICx, (uint8_t)(setValue));
	I2CTimeout = HDC1080_FLAG_TIMEOUT;   //�ȴ����ͽ���  
  while(!I2C_CheckEvent(IICx, I2C_EVENT_MASTER_BYTE_TRANSMITTED)){ 
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	
	I2C_GenerateSTOP(IICx, ENABLE);
	
	/* 2, Trigger the measurements, executing a point write to 0x00*/
	I2C_GenerateSTART(IICx, ENABLE);
	I2CTimeout = HDC1080_FLAG_TIMEOUT;   //�ȴ���ʼ�źŷ������
  while(!I2C_CheckEvent(IICx, I2C_EVENT_MASTER_MODE_SELECT)){  /* Test on EV5 and clear it */
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	
	I2C_Send7bitAddress(IICx, ADDRESS_HDC1080, I2C_Direction_Transmitter);
	I2CTimeout = HDC1080_FLAG_TIMEOUT;   //�ȴ����ͽ���  
  while(!I2C_CheckEvent(IICx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)){ 
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	
	I2C_SendData(IICx, ADDRESS_TEMPERATURE);
	I2CTimeout = HDC1080_FLAG_TIMEOUT;   //�ȴ����ͽ���  
  while(!I2C_CheckEvent(IICx, I2C_EVENT_MASTER_BYTE_TRANSMITTED)){ 
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	
	//I2C_GenerateSTOP(IICx, ENABLE);
	
	/* 3, Wait for the measurement to complete*/
	DelayMs(&operationTime, 20);/*14 bit resolution config correspding 6.5ms of conversion time*/
	/* 4, Read the temperature and humidity data*/
	return 0;
}

/*
����: ͬʱ��ȡ HDC1080 �¶���ʪ��
*/
uint8_t ReadHDC1080(I2C_TypeDef * IICx, uint16_t *temperature, uint16_t *humidity){
	uint16_t I2CTimeout=0;
	
	/* 2, Trigger the measurements, executing a point write to 0x00*/
	I2C_GenerateSTART(IICx, ENABLE);
	I2CTimeout = HDC1080_FLAG_TIMEOUT;   //�ȴ���ʼ�źŷ������
  while(!I2C_CheckEvent(IICx, I2C_EVENT_MASTER_MODE_SELECT)){  /* Test on EV5 and clear it */
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	
	I2C_Send7bitAddress(IICx, ADDRESS_HDC1080, I2C_Direction_Transmitter);
	I2CTimeout = HDC1080_FLAG_TIMEOUT;   //�ȴ����ͽ���  
  while(!I2C_CheckEvent(IICx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)){ 
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	
	I2C_SendData(IICx, ADDRESS_TEMPERATURE);
	I2CTimeout = HDC1080_FLAG_TIMEOUT;   //�ȴ����ͽ���  
  while(!I2C_CheckEvent(IICx, I2C_EVENT_MASTER_BYTE_TRANSMITTED)){ 
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	
	//I2C_GenerateSTOP(IICx, ENABLE);
	
	/* 3, Wait for the measurement to complete*/
	DelayMs(&operationTime, 20);/*14 bit resolution config correspding 6.5ms of conversion time*/

	/* 4, Read the temperature and humidity data*/
	I2C_GenerateSTART(IICx, ENABLE);
	I2CTimeout = HDC1080_FLAG_TIMEOUT;   //�ȴ��źŲ�����
  while(!I2C_CheckEvent(IICx, I2C_EVENT_MASTER_MODE_SELECT)){  /* Test on EV5 and clear it */
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	
	I2CTimeout = I2CT_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(EEPROM_I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED))
  {
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	*temperature = (uint16_t)I2C_ReceiveData(IICx)<<8;
	
	while(!I2C_CheckEvent(EEPROM_I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED))
  {
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	*temperature += I2C_ReceiveData(IICx);
	
	while(!I2C_CheckEvent(EEPROM_I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED))
  {
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	*humidity = (uint16_t)I2C_ReceiveData(IICx)<<8;
	
	while(!I2C_CheckEvent(EEPROM_I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED))
  {
    if((I2CTimeout--) == 0) return HDC_TIMEOUT_UserCallback(0);
  }
	*humidity += I2C_ReceiveData(IICx);
	I2C_GenerateSTOP(IICx, ENABLE);
	return 0;
}


uint8_t HDC_TIMEOUT_UserCallback(uint8_t ERROR_CODE){
	return 0;
}


