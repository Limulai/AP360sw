#include "stm32f10x.h"

void vTaskCmdWater( void *pvParameters );
void start_send(void);
//void get_data(void);
void need_send(void);
void need_para(void);
void send_data(void);
void verify_get(void);
void verify_sent(uint8_t (*buffer)[15],uint8_t which_data,uint8_t data);
void clear_buffer(uint8_t (*buffer)[15]);
void make_data(void);
