#include "api_led.h"
#include "BSP_AP360_GPIO.H"

apLeds allLeds;



void InitAllLeds(void) {
	allLeds.brightness = BRIGHTNESS_DEFAULT;
	allLeds.light_enable = 1;
	//allLeds.brightFlashPeriodNms = 10;
	allLeds.userFlashPeriodNus = 100000;
	allLeds.userLightDurationNus = 100000;
	
	allLeds.ledPower.color = green;
	allLeds.ledPower.state = LIGHT_OFF;
	allLeds.ledPower.enableFlash4User = DISABLE_FLASH4USER;
	allLeds.ledBoost.color = green;
	allLeds.ledBoost.state = LIGHT_OFF;
	allLeds.ledBoost.enableFlash4User = DISABLE_FLASH4USER;
	allLeds.ledHigh.color = green;
	allLeds.ledHigh.state = LIGHT_OFF;
	allLeds.ledHigh.enableFlash4User = DISABLE_FLASH4USER;
	allLeds.ledMid.color = green;
	allLeds.ledMid.state = LIGHT_OFF;
	allLeds.ledMid.enableFlash4User = DISABLE_FLASH4USER;
	allLeds.ledLow.color =green;
	allLeds.ledLow.state = LIGHT_OFF;
	allLeds.ledLow.enableFlash4User = DISABLE_FLASH4USER;
	allLeds.ledDrying.color = green;
	allLeds.ledDrying.state = LIGHT_OFF;
	allLeds.ledDrying.enableFlash4User = DISABLE_FLASH4USER;
	allLeds.ledClean.color = green;
	allLeds.ledClean.state = LIGHT_OFF;
	allLeds.ledClean.enableFlash4User = DISABLE_FLASH4USER;
}

uint8_t SetLedState(uint8_t whichLed, uint8_t state) {
	switch (whichLed) {
		case LED_POWER:
			allLeds.ledPower.state = state;
			break;
		case LED_BOOST:
			allLeds.ledBoost.state = state;
			break;
		case LED_HIGH:
			allLeds.ledHigh.state = state;
			break;
		case LED_MID:
			allLeds.ledMid.state = state;
			break;
		case LED_LOW:
			allLeds.ledLow.state = state;
			break;
		case LED_DRYING:
			allLeds.ledDrying.state = state;
			break;
		case LED_CLEAN:
			allLeds.ledClean.state = state;
			break;
		case LED_ALL:
			allLeds.ledPower.state = state;
			allLeds.ledBoost.state = state;
			allLeds.ledHigh.state = state;
			allLeds.ledMid.state = state;	
			allLeds.ledLow.state = state;
			allLeds.ledDrying.state = state;
			allLeds.ledClean.state = state;
			break;
		default:
			break;
		
	}
	return 1;
}

uint8_t SetLedColor(uint8_t whichLed, ledColor color) {
	switch (whichLed) {
		case LED_POWER:
			allLeds.ledPower.color = color;
			break;
		case LED_BOOST:
			allLeds.ledBoost.color = color;
			break;
		case LED_HIGH:
			allLeds.ledHigh.color = color;
			break;
		case LED_MID:
			allLeds.ledMid.color = color;
			break;
		case LED_LOW:
			allLeds.ledLow.color = color;
			break;
		case LED_DRYING:
			allLeds.ledDrying.color = color;
			break;
		case LED_CLEAN:
			allLeds.ledClean.color = color;
			break;
		default:
			break;
		
	}
	return 1;
}

uint8_t SetLedFlashEnable(uint8_t whichLed, uint8_t onoff) {
	switch (whichLed) {
		case LED_POWER:
			allLeds.ledPower.enableFlash4User = onoff;
			break;
		case LED_BOOST:
			allLeds.ledBoost.enableFlash4User = onoff;
			break;
		case LED_HIGH:
			allLeds.ledHigh.enableFlash4User = onoff;
			break;
		case LED_MID:
			allLeds.ledMid.enableFlash4User = onoff;
			break;
		case LED_LOW:
			allLeds.ledLow.enableFlash4User = onoff;
			break;
		case LED_DRYING:
			allLeds.ledDrying.enableFlash4User = onoff;
			break;
		case LED_CLEAN:
			allLeds.ledClean.enableFlash4User = onoff;
			break;
		default:
			break;
		
	}
	return 1;
}


uint8_t SetLightEnable (uint8_t onoff){
	if (onoff == ENABLE_LIGHT || onoff == DISABLE_LIGHT) {
		allLeds.light_enable = onoff;
		return 1;
	}
	else
		return 0;
}

uint8_t GetLightEnable(void){
	return allLeds.light_enable;
}

uint8_t SetBrightness(uint8_t brightness) {
	if((brightness <= BRIGHTNESS_MAX)) {
		allLeds.brightness = brightness;
		return 1;
	}
	else
		return 0;
}

uint8_t GetBrightness(void){
	return allLeds.brightness;
}


uint8_t SetUserFlashPeriod(uint32_t userFlashPeriodNus) {
	allLeds.userFlashPeriodNus = userFlashPeriodNus;
	return 1;
}

uint8_t SetUserLightDuration(uint32_t userLightDurationNus) {
	allLeds.userLightDurationNus = userLightDurationNus;
	return 1;
}


/*
	private function for manual leds
*/
uint8_t LedOnOff(uint8_t whichLed, uint8_t onoff) {
	switch (whichLed){
		case LED_POWER:
			if (onoff == ON) {
				if (allLeds.ledPower.color == green) {
					LED_POWER_GREEN();
				}
				else if (allLeds.ledPower.color == blue) {
					LED_POWER_BLUE();
				}
			}
			else if (onoff == OFF) {
				LED_POWER_OFF();
			}
			break;
		case LED_BOOST:
			if (onoff == ON) {
				if (allLeds.ledBoost.color == green) {
					LED_BOOST_GREEN();
				}
				else if (allLeds.ledBoost.color == orange) {
					LED_BOOST_ORANGE();
				}
				else if (allLeds.ledBoost.color == red) {
					LED_BOOST_RED();
				}
			}
			else if (onoff == OFF) {
				LED_BOOST_OFF();
			}
			break;
		case LED_HIGH:
			if (onoff == ON) {
				LED_HIGH_GREEN();
			}
			else if (onoff == OFF) {
				LED_HIGH_OFF();
			}
			break;
		case LED_MID:
			if (onoff == ON) {
				LED_MID_GREEN();
			}
			else if (onoff == OFF) {
				LED_MID_OFF();
			}
			break;
		case LED_LOW:
			if (onoff == ON) {
				LED_LOW_GREEN();
			}
			else if (onoff == OFF) {
				LED_LOW_OFF();
			}
			break;
		case LED_DRYING:
			if (onoff == ON) {
				LED_DRYING_GREEN();
			}
			else if (onoff == OFF) {
				LED_DRYING_OFF();
			}
			break;
		case LED_CLEAN:
			if (onoff == ON) {
				LED_CLEAN_GREEN();
			}
			else if (onoff == OFF) {
				LED_CLEAN_OFF();
			}
			break;
		default:
			break;
	}
	
	return 1;
}

void LedsBrightnessAdj(void){
	static uint8_t counterFlash4Brightness=0;
	static uint8_t counterFlash4User=0;
	counterFlash4Brightness ++;
											/* CYC_TIMER_BRIGHTNESS_FLASH * BRIGHTNESS_MAX = CYC_BRIGHTNESS_FLASH */
	if (counterFlash4Brightness >= BRIGHTNESS_MAX) {
		counterFlash4Brightness = 0;
		counterFlash4User++;
		if (counterFlash4User >= (allLeds.userFlashPeriodNus / CYC_BRIGHTNESS_FLASH)) 
			counterFlash4User=0;
	}
	
	if (counterFlash4Brightness % BRIGHTNESS_MAX ==0)// ����
	{
		if (allLeds.light_enable == ENABLE_LIGHT){
			
			if(allLeds.ledPower.state == LIGHT_ON) {
				LedOnOff(LED_POWER, ON);
			}
			if(allLeds.ledBoost.state == LIGHT_ON) {
				LedOnOff(LED_BOOST, ON);
			}
			if(allLeds.ledHigh.state == LIGHT_ON) {
				LedOnOff(LED_HIGH, ON);
			}
			if(allLeds.ledMid.state == LIGHT_ON) {
				LedOnOff(LED_MID, ON);
			}
			if(allLeds.ledLow.state == LIGHT_ON) {
				LedOnOff(LED_LOW, ON);
			}
			if(allLeds.ledDrying.state == LIGHT_ON) {
				LedOnOff(LED_DRYING, ON);
			}
			if(allLeds.ledClean.state == LIGHT_ON) {
				LedOnOff(LED_CLEAN, ON);
			}
		}// END ALL ENABLE	
	}
	else if(counterFlash4Brightness %100 == allLeds.brightness) //����
	{
		LED_POWER_OFF();
		LED_BOOST_OFF();
		LED_HIGH_OFF();
		LED_MID_OFF();
		LED_LOW_OFF();
		LED_DRYING_OFF();
		LED_CLEAN_OFF();
	}
}



/*
	@ This delay function adapts to 72M frequency system clock.
*/
extern void delay_ms(unsigned int ms);
#define POWER_ON_SIGNAL_DELAY()  delay_ms(100)
void PowerOnSignal(void){
	allLeds.ledClean.state = LIGHT_ON;
	POWER_ON_SIGNAL_DELAY();
	allLeds.ledClean.state = LIGHT_OFF;
	allLeds.ledDrying.state = LIGHT_ON;
	POWER_ON_SIGNAL_DELAY();
	allLeds.ledDrying.state = LIGHT_OFF;
	allLeds.ledLow.state = LIGHT_ON;
	POWER_ON_SIGNAL_DELAY();
	allLeds.ledLow.state = LIGHT_OFF;
	allLeds.ledMid.state = LIGHT_ON;
	POWER_ON_SIGNAL_DELAY();
	allLeds.ledMid.state = LIGHT_OFF;
	allLeds.ledHigh.state = LIGHT_ON;
	POWER_ON_SIGNAL_DELAY();
	allLeds.ledHigh.state = LIGHT_OFF;
	allLeds.ledBoost.state = LIGHT_ON;
	POWER_ON_SIGNAL_DELAY();
	allLeds.ledBoost.state = LIGHT_OFF;
	allLeds.ledPower.state = LIGHT_ON;
	POWER_ON_SIGNAL_DELAY();
	allLeds.ledPower.state = LIGHT_OFF;
}


