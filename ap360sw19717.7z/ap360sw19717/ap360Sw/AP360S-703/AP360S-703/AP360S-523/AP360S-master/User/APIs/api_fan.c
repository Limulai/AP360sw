#include "api_fan.h"
#include "BSP_TIMER.h" 
#include "FreeRTOS.h"
#include "task.h"
#include "event_groups.h"
#include "semphr.h"
#include "BSP_AP360_GPIO.H"
#include "api_led.h"
#include "UARTprintf.h"


/*=================================Fan ���==============================================================================*/
static Fan_Status fan;
static TimerHandle_t fan_tm = NULL;
static TimerHandle_t boost_tm = NULL;
void TimerFan(TimerHandle_t pxTimer);
void AdjFanMode(Fan_Mode fan_mode);
void BoostCounter(TimerHandle_t pxTimer);
void SetFanLeds(void);
void SetVoltWithFan(void);
extern uint8_t state;
//uint8_t Gradual_volt=93;
uint8_t Gradual_volt=100;
uint8_t Fan_mode_old=7;
uint8_t water_flag=0;
static TimerHandle_t high_volt_gradual = NULL;

#define FAN_TIMER_ID 5
#define BOOST_TIMER_ID 6
#define BOOST_DURATION ((uint16_t)(60*20))

void InitFan(void){
	fan.fan_mode = DEFAULT_FAN_MODE;
	fan.fan_onoff = FAN_OFF;
	fan.fan_pwm = 0;
	fan_tm = xTimerCreate("FT", configTICK_RATE_HZ/5, pdTRUE, (void *)FAN_TIMER_ID, TimerFan );	
	if (fan_tm == NULL) {
		// creation failed
	}
	boost_tm = xTimerCreate("BT", configTICK_RATE_HZ*BOOST_DURATION, pdFALSE, (void *)BOOST_TIMER_ID, BoostCounter);
	if (boost_tm == NULL) {
		//failed
	}
				/* Shut the fan down */
	SetFanPWM(0);
}

void SetFanOnoff(Fan_Onoff onoff){
	fan.fan_onoff = onoff;
}

void SetFanMode(Fan_Mode fan_mode){
	fan.fan_mode = fan_mode;
}

void SetFanPWMPara(uint8_t pwm){
	if (pwm <= 100) {
		fan.fan_pwm = pwm;
	}
}

Fan_Status * GetFanStatus(void) {
	return &fan;
}

Fan_Mode GetFanMode(void) {
	return fan.fan_mode;
}


void BoostCounter(TimerHandle_t pxTimer) {
									/* implement only when the fan on and fan mode is boost*/
	if (fan.fan_onoff == FAN_ON && fan.fan_mode == BOOST) {
		AdjFanMode(AFTER_BOOST_FAN_MODE);	
	}
	
}

static uint8_t setting_pwm;
void TimerFan(TimerHandle_t pxTimer){
	if (fan.fan_pwm < setting_pwm) {
			if ((setting_pwm - fan.fan_pwm) / 10 > 0) {
				fan.fan_pwm += 10;
				SetFanPWM(fan.fan_pwm);
			}
			else {
				fan.fan_pwm = setting_pwm;
				SetFanPWM(fan.fan_pwm);
				if (xTimerStop(fan_tm, 50) == pdFAIL) {
				// STOP FAILED
				}
			}
	}
	else if (fan.fan_pwm > setting_pwm) {
		if ((fan.fan_pwm - setting_pwm) / 10 > 0) {
			fan.fan_pwm -= 10;
			SetFanPWM(fan.fan_pwm);
		}
		else {
			fan.fan_pwm = setting_pwm;
			SetFanPWM(fan.fan_pwm);
			if (xTimerStop(fan_tm, 50) == pdFAIL) {
			// STOP FAILED
			}
		}
	}
	else {
		if (xTimerStop(fan_tm, 50) == pdFAIL) {
			// STOP FAILED
		}	
	}
}

void AdjFanPWM(uint8_t pwm){
	setting_pwm = pwm;
	if (xTimerStart(fan_tm, 100) != pdPASS) {
		// start failed
	}
}

void SetFanLeds(void) {
	if (fan.fan_onoff == FAN_OFF) {
		SetLedState(LED_HIGH, LIGHT_OFF);
		SetLedState(LED_MID, LIGHT_OFF);
		SetLedState(LED_LOW, LIGHT_OFF);
	}
	else if (fan.fan_onoff == FAN_ON) {
		switch (fan.fan_mode) {
		case STOP:
			SetLedState(LED_HIGH, LIGHT_OFF);
			SetLedState(LED_MID, LIGHT_OFF);
			SetLedState(LED_LOW, LIGHT_OFF);
			break;
		case LOW:
			SetLedState(LED_HIGH, LIGHT_OFF);
			SetLedState(LED_MID, LIGHT_OFF);
			SetLedState(LED_LOW, LIGHT_ON);
			break;
		case MID:
			SetLedState(LED_HIGH, LIGHT_OFF);
			SetLedState(LED_MID, LIGHT_ON);
			SetLedState(LED_LOW, LIGHT_OFF);
			break;
		case HIGH:
			SetLedState(LED_HIGH, LIGHT_ON);
			SetLedState(LED_MID, LIGHT_OFF);
			SetLedState(LED_LOW, LIGHT_OFF);
			break;
		case BOOST:
			SetLedState(LED_HIGH, LIGHT_ON);
			SetLedState(LED_MID, LIGHT_ON);
			SetLedState(LED_LOW, LIGHT_ON);
			break;
		default:
			break;
		}
	}
}


uint8_t SwitchMode2PWM(Fan_Mode fan_mode){
	uint8_t temp_pwm;
	switch (fan_mode) {
		case STOP:
			temp_pwm = FAN_PWM_STOP;
			break;
		case LOW:
			temp_pwm = FAN_PWM_LOW;
			break;
		case MID:
			temp_pwm = FAN_PWM_MID;
			break;
		case HIGH:
			temp_pwm = FAN_PWM_HIGH;
			break;
		case BOOST:
			temp_pwm = FAN_PWM_BOOST;
			break;
		default:
			temp_pwm = FAN_PWM_STOP;
			break;
	}
	return temp_pwm;
}


void TurnOffFan(void) {
	AdjFanPWM(SwitchMode2PWM(STOP));
	fan.fan_onoff = FAN_OFF;
	SetFanLeds();
	SetVoltWithFan();
}

void TurnOnFan(void) {
			/* ����������Ҫ��ֹ��ͻ���PWM�����䷴������������� */
	if (fan.fan_mode != STOP) {
		SetFanPWM(FAN_PWM_LOW);
		fan.fan_pwm = FAN_PWM_LOW;
	}
	AdjFanPWM(SwitchMode2PWM(fan.fan_mode));
	if (fan.fan_mode == BOOST) {
		xTimerStart(boost_tm, 50);
	}
	fan.fan_onoff = FAN_ON;
	SetFanLeds();
	SetVoltWithFan();
}


void AdjFanMode(Fan_Mode fan_mode){
	if ((fan.fan_onoff == FAN_ON)||(water_flag==1)) {
					/* ����������Ҫ��ֹ��ͻ���PWM�����䷴������������� */
		if (fan.fan_mode == STOP && fan_mode != STOP) {
			SetFanPWM(FAN_PWM_LOW);
			fan.fan_pwm = FAN_PWM_LOW;
		}
		AdjFanPWM(SwitchMode2PWM(fan_mode));
		fan.fan_mode = fan_mode;
		if (fan.fan_mode == BOOST) {
			xTimerStart(boost_tm, 50);
		}
		water_flag=0;
	}
	SetFanLeds();
	SetVoltWithFan();
}

void AdjFanRecurrently(void) {
	Fan_Mode next_fan_mode;
	switch (fan.fan_mode) {
		case STOP:
			next_fan_mode = LOW;
			break;
		case LOW:
			next_fan_mode = MID;
			break;
		case MID:
			next_fan_mode = HIGH;
			break;
		case HIGH:
			next_fan_mode = BOOST;
			break;
		case BOOST:
			next_fan_mode = STOP;
			break;
		default:
			break;
	}
	if (fan.fan_onoff == FAN_ON) {
		AdjFanMode(next_fan_mode);
		fan.fan_mode = next_fan_mode;
	}
	
}


/*=================================��ѹ����=====================================================*/
typedef struct{
	uint8_t isHighVoltOn:1;
	uint8_t isHighVoltStable:1;
	uint8_t reserve:6; 
}highVoltState_t;
static highVoltState_t highVoltState={0,0,0};


uint8_t IsHighVoltOn(void){
	return highVoltState.isHighVoltOn;
}

uint8_t IsHighVoltStable(void){
	return highVoltState.isHighVoltStable;
}
//static uint8_t g_isHighVoltStable=0;
//static uint8_t abnormal_times_to_clean_isHighVoltStable=0;
void TimerHighVoltStable(TimerHandle_t pxTimer){
	if(highVoltState.isHighVoltOn==1){
		highVoltState.isHighVoltStable = 1;
	}	
	//printf("stable%d\r\n",Gradual_volt);
}

	/* ------- ------------  ----------------  ----------------*/
void GRADUAL_TIMER_CALLBACK(TimerHandle_t pxTimer)
{
	if(Gradual_volt>76) Gradual_volt-=1;
	
//	if((Gradual_volt>84)&&(Gradual_volt<99)) 
//		{ 		
//			SetVoltPWM(Gradual_volt+Gradual_volt%2);
//		}
//	
//	else                {	SetVoltPWM(Gradual_volt)  ;}
	SetVoltPWM(Gradual_volt)  ;
		
	if(Gradual_volt<76)
	{  
		 Gradual_volt=76;
	   xTimerStop(high_volt_gradual,100);
		 SetVoltPWM(Gradual_volt);
		 high_volt_gradual=NULL;
	}
		if(fan.fan_onoff == FAN_OFF)
	{
	    
	   xTimerStop(high_volt_gradual,100);
		// Gradual_volt=93;
		 Gradual_volt=100;
		 HIGH_VOLT_OFF();
		 high_volt_gradual=NULL;
	}
	if(Gradual_volt<80)
	{
	  state=1;
	}
}


	/* ------- ----------------  --------------  --------------*/

void HIGH_VOLT_ON(void)
	{
	//uint8_t i = 1;
	static TimerHandle_t high_volt_stable_tm = NULL;
	digitalHi(high_volt_on_off_GPIO_Port,high_volt_on_off_Pin );
	highVoltState.isHighVoltOn =1;
	if(Fan_mode_old!=fan.fan_mode)	
	{   
		 Fan_mode_old=fan.fan_mode;
		 if(high_volt_gradual != NULL)
		  xTimerStop(high_volt_gradual,100);
		 
		 high_volt_gradual = NULL;
	
	}
	if (high_volt_stable_tm == NULL){
		high_volt_stable_tm = xTimerCreate("timer", configTICK_RATE_HZ*2, pdFALSE, (void *)1, TimerHighVoltStable );	
	}
	/* ------- --------------------------------------------*/
	if (high_volt_gradual == NULL){
		if(fan.fan_mode!=STOP)
		{
			
		 
		 if(Gradual_volt>=97)	
     {
		     high_volt_gradual = xTimerCreate("gradual_timer", configTICK_RATE_HZ*3, pdTRUE, (void *)9, GRADUAL_TIMER_CALLBACK );
		     xTimerReset(high_volt_gradual, 100);
		 }	
		 
		 		 if((Gradual_volt<97)&&(Gradual_volt>=95))	
     {
		     high_volt_gradual = xTimerCreate("gradual_timer", configTICK_RATE_HZ*25, pdTRUE, (void *)9, GRADUAL_TIMER_CALLBACK );
		     xTimerReset(high_volt_gradual, 100);
		 }

     if((Gradual_volt>90)&&((Gradual_volt<95)))
     {
		     high_volt_gradual = xTimerCreate("gradual_timer", configTICK_RATE_HZ*10, pdTRUE, (void *)9, GRADUAL_TIMER_CALLBACK );
		     xTimerReset(high_volt_gradual, 100);
		 }	
     if(Gradual_volt<=90)
     {
		     high_volt_gradual = xTimerCreate("gradual_timer", configTICK_RATE_HZ*4, pdTRUE, (void *)9, GRADUAL_TIMER_CALLBACK );
		     xTimerReset(high_volt_gradual, 100);
		 }			 

		}

		 //Gradual_volt=93;
		Gradual_volt=100;
	}
	/* ------- --------------------------------------------*/
	xTimerReset(high_volt_stable_tm, 100);//��ʱ����δ����������״̬��xTimerReset������ЧxTimerStart����
	//printf("hight voltage on.\r\n");
//	if(Gradual_volt<76)
//	{
//	   xTimerStop(high_volt_gradual,100);
//	}
}
void HIGH_VOLT_OFF(void){
	SetVoltPWM(0);
	digitalLo(high_volt_on_off_GPIO_Port,high_volt_on_off_Pin );
	highVoltState.isHighVoltOn =0;
	highVoltState.isHighVoltStable = 0;	
	//printf("hight voltage off.\r\n");
}

void SetVoltWithFan(void) {
	if (fan.fan_onoff == FAN_OFF) {
		HIGH_VOLT_OFF();
	}
	else if (fan.fan_onoff == FAN_ON) {
		HIGH_VOLT_ON();
		
		switch (fan.fan_mode) {
		case STOP:
			SetVoltPWM(VOLT_PWM_STOP);
			break;
		case LOW:
		  state=0;
		  SetVoltPWM(Gradual_volt);
			//SetVoltPWM(VOLT_PWM_LOW);
		   //printf("low.\r\n");
			break;
		case MID:
			state=0;
		  SetVoltPWM(Gradual_volt);
			//SetVoltPWM(VOLT_PWM_MID);
			break;
		case HIGH:
			state=0;
		  SetVoltPWM(Gradual_volt);
			//SetVoltPWM(VOLT_PWM_HIGH);
			break;
		case BOOST:
		  state=0;
		  SetVoltPWM(Gradual_volt);
			//SetVoltPWM(VOLT_PWM_BOOST);
			break;
		default:
			break;

		}
	}
}




