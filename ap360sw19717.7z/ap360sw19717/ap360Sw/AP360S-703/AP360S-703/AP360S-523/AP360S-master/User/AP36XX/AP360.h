#ifndef __AP360_H
#define __AP360_H

#include <stm32f10x.h>

/*==============================��������������־������======================================================*/
extern uint8_t g_key_power_action; //key_power ����ȫ�ֱ���
extern uint8_t g_key_mode_action;		//key_mode ����ȫ�ֱ���
extern uint8_t g_key_boost_action;		//key_boost ����ȫ�ֱ���

/*=================================boost ģʽ��־����======================================================*/
extern uint8_t g_boost_start;
extern uint8_t g_boost_running;

/*=================================ϵͳģʽ  ======================================================*/
#define DRYING_TIME   1  //����ģʽ����ʱ������λ������; ��Χ��0-60
#define BOOST_TIME    10 //boost ģʽ����ʱ������λ����

typedef enum
{
    MODE_NORMAL = 0,//normal
    MODE_DRYING = 1,//drying
    MODE_CLEAN = 2,//clean
    MODE_FAULT = 3,//fault
    MODE_POWEROFF = 4,//poweroff
    //STATUS_VALUE_MAX,
} MODE;
extern MODE g_SystemStatus;

#define BEGINNING 1
#define N_BEGINNING 0
#define SET_TO_MODE_NORMAL 1
#define SET_TO_MODE_POWEROFF 2
#define SET_TO_MODE_FAULT 3
#define SET_TO_MODE_DRYING 4
#define SET_TO_MODE_CLEAN 5
typedef struct{
	uint8_t mode_normal_beginning;
	uint8_t mode_drying_beginning;
	uint8_t mode_clean_beginning;
	uint8_t mode_fault_beginning;
	uint8_t mode_poweroff_beginning;

}	SystemMode_Beginning_Handle;
extern SystemMode_Beginning_Handle g_system_mode_beginning;
void ModeSetting(uint8_t mode);
uint8_t ModeNormal(void);
uint8_t ModeShutdown(void);
uint8_t ModeDrying(void);
uint8_t ModeClean(void);
uint8_t ModeFault(void);

/*=================================LED ���=====================================================*/
#define LED_ON 0
#define LED_OFF 1
/*LED ���ȵȼ�*/
#define BRIGHTNESS_HIGHEST 4
#define BRIGHTNESS_HIGH    3
#define BRIGHTNESS_MID     2
#define BRIGHTNESS_LOW     1
#define BRIGHTNESS_DEFAULT 4

/*LED ���ƽṹ�壬Ԫ�ض�ӦLEDҪ���õ�ֵ�Լ�LED������*/
typedef struct{
	uint8_t led_power;
	uint8_t led_boost;
	uint8_t led_high;
	uint8_t led_mid;
	uint8_t led_low;
	uint8_t led_drying;
	uint8_t led_clean;

	uint8_t led_brightness;
}Leds_Control;
/*led ����������*/
extern Leds_Control leds_control;
void LedsBrightnessAdj(Leds_Control *leds_control);
void ShutAllLeds(void);
void ResumeLeds(void);

/*=================================Fan ���=====================================================*/
#define FAN_BOOST_ADJUST 0
#define FAN_NORMAL_ADJUST 1

#define FAN_RESUME 1
#define FAN_ADJ   2

#define FAN_PWM_STOP 0
#define FAN_PWM_LOW 16
#define FAN_PWM_MID 40
#define FAN_PWM_HIGH 90
#define FAN_PWM_BOOST 97

/*����״̬�ṹ��ͱ�������*/
typedef enum{	
	LOW,
	MID,
	HIGH,
	STOP,
	BOOST
}Fan_Mode;
extern Fan_Mode g_fan_mode;
extern Fan_Mode g_fan_last_mode;
void StopFun(void);
void RuningFun(void);
void SetFanPwmDuty(Fan_Mode fanMode);
void FanMode_ADJ(Fan_Mode * fanMode, uint8_t boost_or_normal, uint8_t resume_or_adj);

/*=================================��ѹ����=====================================================*/

#define HIGH_VOLT_STABLE 1
#define HIGH_VOLT_STABLE_DELAY 2  //��λ����
//extern uint8_t high_volt_on_time;
extern uint8_t g_isHighVoltStable;
//#define HIGH_VOLT_ON()			digitalHi(high_volt_on_off_GPIO_Port,high_volt_on_off_Pin )
//#define HIGH_VOLT_OFF()			digitalLo(high_volt_on_off_GPIO_Port,high_volt_on_off_Pin )
//#define HIGH_VOLT_REF_ON()			digitalLo(high_volt_ref_GPIO_Port,high_volt_ref_Pin )
//#define HIGH_VOLT_REF_OFF()			digitalHi(high_volt_ref_GPIO_Port,high_volt_ref_Pin )

void HIGH_VOLT_OFF(void);
void HIGH_VOLT_ON(void);



/*=================================������====================================================*/
extern float g_temperature;
extern float g_humidity;
void GetTemperatureHumidity(float *temp_f, float *humi_f);
void GetCH2O_N_PM25(void);
void PrintTemperatureHumidity(void);

/*================================ADC Ӧ�ú���====================================================*/
#define TUNGSTEN_VOLT_LOWER_LIMIT 1.0f  //��˿��ѹӦ���ڴ˵�ѹ������Ϊ2.5V����
#define ALARM_VOLT_UPPER_LIMIT 0.902f
#define ALARM_VOLT_LOWER_LIMIT 0.285f
#define ALARM_SEMAPHORE 0x02
#define TUNGSTEN_A_BREAK 0X01
#define TUNGSTEN_B_BREAK 0X04
#define TUNGSTEN_AB_BREAK 0X05

void GetVoltDiode_N_Adj(void);
uint8_t GetVoltAlarm_N_Adj(void);
uint8_t GetVoltTungsten_N_Adj(void);



/*===============================  Cleanģʽʱ���ۻ�  =================================================*/
//extern uint16_t ACC_running_timer; //����ϵͳ�ۻ�����ʱ��

void GetArtFromEEPROM(void);
void ART_ADJ(void);


/*===============================  ����  ===================================================*/
extern uint8_t g_fault_code;
extern uint8_t g_tungsten_break;
extern uint8_t g_alarm;

//void AirLinkMode(void);
void BoostMode_CountDown(void);
void ModeFaultHandle(uint8_t fault_code);


#define HUMIDITY_MAX 0.95f
#define CLAEN_TIME_MAX  3  //��λ: minute
#define CLEAN_TIME_HIGH  1
#define CLEAN_TIME_LOW   0
#define CLEAN_TIME_ADDR 0x00

extern uint8_t g_clean_time[];
uint8_t CleanTimeCountHandle(void);

#endif	/* __AP360_H */


