#ifndef		__SW_FIFO_H
#define		__SW_FIFO_H

//#define STM32_HAL
#ifdef STM32_HAL
#include "stm32f1xx_hal.h"
#else
#include "stm32f10x.h"
#endif

#define FIFO_BUFFER_SIZE 64 // software buffer size (in bytes)

 
typedef struct {
  uint8_t  data_buf[FIFO_BUFFER_SIZE]; // FIFO buffer
  uint16_t i_first;                    // index of oldest data byte in buffer
  uint16_t i_last;                     // index of newest data byte in buffer
  uint16_t num_bytes;                  // number of bytes currently in buffer
	uint8_t fifo_not_empty_flag;
	uint8_t fifo_full_flag;
	uint8_t fifo_ovf_flag;
}sw_fifo_typedef;

//extern sw_fifo_typedef uart1_rx_fifo;
//extern sw_fifo_typedef uart2_rx_fifo;
extern sw_fifo_typedef uart3_rx_fifo;
extern sw_fifo_typedef uart1_tx_fifo;

// UART data transmit function
//  - checks if there's room in the transmit sw buffer
//  - if there's room, it transfers data byte to sw buffer 
//  - automatically handles "uart_tx_buffer_full_flag"
//  - sets the overflow flag upon software buffer overflow (doesn't overwrite existing data)
//  - if this is the first data byte in the buffer, it enables the "hw buffer empty" interrupt
//void uart_send_byte(uint8_t byte);


// UART data receive function
//  - checks if data exists in the receive sw buffer
//  - if data exists, it returns the oldest element contained in the buffer 
//  - automatically handles "uart_rx_buffer_full_flag"
//  - if no data exists, it clears the uart_rx_flag
#ifdef STM32_HAL
uint8_t uart_get_byte(UART_HandleTypeDef *huart, sw_fifo_typedef *rx_fifo); 
#else
uint8_t uart_get_byte(USART_TypeDef* USARTx, sw_fifo_typedef *rx_fifo); 
#endif
void uart_send_byte(USART_TypeDef* USARTx, sw_fifo_typedef *tx_fifo, uint8_t byte);
void software_uart_receive_interrupt_subroutine(sw_fifo_typedef *rx_fifo, uint8_t byte);
void software_uart_transmit_interrupt_subroutine(USART_TypeDef* USARTx, sw_fifo_typedef *tx_fifo);
void uart1_send_buff(uint8_t *buf, uint8_t num);

#endif
