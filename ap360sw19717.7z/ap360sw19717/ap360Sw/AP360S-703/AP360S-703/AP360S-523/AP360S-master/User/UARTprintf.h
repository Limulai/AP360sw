#ifndef __UARTPRINTF_H__
#define __UARTPRINTF_H__
#include "stm32f10x.h"


void UARTprintf(const uint8_t *pcString, ...);









#endif

