#include "cli_zhu.h"
#include "ctype.h"

#include "stdio.h"
#include "string.h"
//#include "debug.h"
#include "app_ap36xx.h"
#include "BSP_EEPROM.h"
#include "BSP_CH2O_N_PM25.h"
#include "UARTprintf.h"
#include "api_led.h"
#include "api_fan.h"

extern uint8_t g_app_connected;

//#define cli_output(message) UARTprintf(message)

void get_task_state(int32_t argc, void *cmd_arg);
void printf_humidity(int32_t argc, void *cmd_arg);  
void printf_clean_time(int32_t argc, void *cmd_arg); 
void printf_boost_time(int32_t argc, void *cmd_arg); 
void printf_drying_time(int32_t argc, void *cmd_arg); 
void set_to_mode_fault(int32_t argc, void *cmd_arg);
void set_to_mode_normal(int32_t argc, void *cmd_arg);
void set_to_mode_poweroff(int32_t argc, void *cmd_arg);
void set_to_mode_clean(int32_t argc, void *cmd_arg);
void set_to_mode_drying(int32_t argc, void *cmd_arg);
void set_clean_time(int32_t argc, void *cmd_arg);
void set_clean_time_max(int32_t argc, void *cmd_arg);
void set_drying_time_max(int32_t argc, void *cmd_arg);
void set_boost_time_max(int32_t argc, void *cmd_arg);
void set_clean_time_resolution(int32_t argc, void *cmd_arg);
void set_drying_time_resolution(int32_t argc, void *cmd_arg);
void set_boost_time_resolution(int32_t argc, void *cmd_arg);
void get_all_parameter(int32_t argc, void *cmd_arg);
void set_mode(int32_t argc, void *cmd_arg);
void set_fan(int32_t argc, void *cmd_arg);
void switch_pm_module(int32_t argc, void *cmd_arg);
void enable_alarm_detect(int32_t argc, void *cmd_arg);
void enable_tungsten_detect(int32_t argc, void *cmd_arg);
void SetLeds(int32_t argc, void *cmd_arg);
void AdjFan(int32_t argc, void *cmd_arg);

//#define windows
/*命令表*/  
const cmd_list_struct cmd_list[]={  
/*   命令    参数数目    处理函数        帮助信息                         */     
//{"hello",   0,      printf_hello,    "hello                      -HelloWorld!"},  
//{"arg",     8,      handle_arg,      "arg<arg1> <arg2> ...      -for test!"},
{"GetHumidity", 0,     printf_humidity,   "print humidity ."},
{"task",   0,       get_task_state,   "task                     get task information."},
{"SCT", 1,     set_clean_time,  "none... "},
{"SCTM", 1,     set_clean_time_max,  "none... "},
{"SCTR", 1,     set_clean_time_resolution,  "none... "},
{"SDTM", 1,     set_drying_time_max,  "none... "},
{"SDTR", 1,     set_drying_time_resolution,  "none... "},
{"SBTM", 1,     set_boost_time_max,  "none... "},
{"SBTR", 1,     set_boost_time_resolution,  "none... "},
{"GetAll", 0,     get_all_parameter,  "none... "},
{"SetMode", 1,     set_mode,  "none... "},
{"SetFan", 1,     set_fan,  "none... "},
//{"SwitchPM", 1,     switch_pm_module,  "none... "},
{"ala", 1,      enable_alarm_detect,  "none... "},
{"tun", 1,      enable_tungsten_detect,  "none... "},
{"SL", 3,      SetLeds,  "none... "},
{"AF", 1,      AdjFan,  "none... "}
}; 


TaskHandle_t xCmdAnalyzeHandle = NULL;
cmd_analyze_struct cmd_analyze;
/*提供给串口中断服务程序，保存串口接收到的单个字符*/
void fill_rec_buf(char data)
{
    //接收数据 
    static uint32_t rec_count=0;
   
   cmd_analyze.rec_buf[rec_count]=data;
	#ifdef windows
	if(0x0D==cmd_analyze.rec_buf[rec_count])
	#else
	if(0x0A==cmd_analyze.rec_buf[rec_count] && 0x0D==cmd_analyze.rec_buf[rec_count-1])
	#endif
    {
       BaseType_t xHigherPriorityTaskWoken = pdFALSE;
       rec_count=0;
       
       /*收到一帧数据，向命令行解释器任务发送通知*/
       vTaskNotifyGiveFromISR (xCmdAnalyzeHandle,&xHigherPriorityTaskWoken);
       
       /*是否需要强制上下文切换*/
       portYIELD_FROM_ISR(xHigherPriorityTaskWoken );
    }
    else
    {
       rec_count++;
       
       /*防御性代码，防止数组越界*/
       if(rec_count>=CMD_BUF_LEN)
       {
           rec_count=0;
       }
    }    
}

/**
* 使用SecureCRT串口收发工具,在发送的字符流中可能带有不需要的字符以及控制字符,
* 比如退格键,左右移动键等等,在使用命令行工具解析字符流之前,需要将这些无用字符以
* 及控制字符去除掉.
* 支持的控制字符有:
*   上移:1B 5B 41
*   下移:1B 5B 42
*   右移:1B 5B 43
*   左移:1B 5B 44
*   回车换行:0D 0A
*  Backspace:08
*  Delete:7F
*/
static uint32_t get_true_char_stream(char *dest,const char *src)
{
   uint32_t dest_count=0;
   uint32_t src_count=0;
   
	#ifdef windows
	while(src[src_count]!=0x0D)
	#else
	while(src[src_count]!=0x0D && src[src_count+1]!=0x0A)
	#endif
    {
       if(isprint(src[src_count]))
       {
           dest[dest_count++]=src[src_count++];
       }
       else
       {
           switch(src[src_count])
           {
                case    0x08:                          //退格键键值
                {
                    if(dest_count>0)
                    {
                        dest_count --;
                    }
                    src_count ++;
                }break;
                case    0x1B:
                {
                    if(src[src_count+1]==0x5B)
                    {
                        if(src[src_count+2]==0x41 || src[src_count+2]==0x42)
                        {
                            src_count +=3;              //上移和下移键键值
                        }
                        else if(src[src_count+2]==0x43)
                        {
                            dest_count++;               //右移键键值
                            src_count+=3;
                        }
                        else if(src[src_count+2]==0x44)
                        {
                            if(dest_count >0)           //左移键键值
                            {
                                dest_count --;
                            }
                           src_count +=3;
                        }
                        else
                        {
                            src_count +=3;
                        }
                    }
                    else
                    {
                        src_count ++;
                    }
                }break;
                default:
                {
                    src_count++;
                }break;
           }
       }
    }
	/* 传递换行符号 */
	dest[dest_count++]=src[src_count++];
	#ifdef windows
	#else
	dest[dest_count++]=src[src_count++];
	#endif
	
    return dest_count;
}

/*字符串转10/16进制数*/
static int32_t string_to_dec(uint8_t *buf,uint32_t len)
{
   uint32_t i=0;
   uint32_t base=10;       //基数
   int32_t  neg=1;         //表示正负,1=正数
   int32_t  result=0;
   
    if((buf[0]=='0')&&(buf[1]=='x'))
    {
       base=16;
       neg=1;
       i=2;
    }
    else if(buf[0]=='-')
    {
       base=10;
       neg=-1;
       i=1;
    }
    for(;i<len;i++)
    {
       if(buf[i]==0x20 || buf[i]==0x0D)    //为空格
       {
           break;
       }
       
       result *= base;
       if(isdigit(buf[i]))                 //是否为0~9
       {
           result += buf[i]-'0';
       }
       else if(isxdigit(buf[i]))           //是否为a~f或者A~F
       {
            result+=tolower(buf[i])-87;
       }
       else
       {
           result += buf[i]-'0';
       }                                        
    }
   result *= neg;
   
    return result ;
}


/**
* 命令参数分析函数,以空格作为一个参数结束,支持输入十六进制数(如:0x15),支持输入负数(如-15)
* @param rec_buf   命令参数缓存区
* @param len       命令的最大可能长度
* @return -1:       参数个数过多,其它:参数个数
*/
static int32_t cmd_arg_analyze(char *rec_buf,unsigned int len)
{
   uint32_t i;
   uint32_t blank_space_flag=0;    //空格标志
   uint32_t arg_num=0;             //参数数目
   uint32_t index[ARG_NUM];        //有效参数首个数字的数组索引
   
    /*先做一遍分析,找出参数的数目,以及参数段的首个数字所在rec_buf数组中的下标*/
    for(i=0;i<len;i++)
    {
       if(rec_buf[i]==0x20)        //为空格
       {
           blank_space_flag=1;              
           continue;
       }
        else if(rec_buf[i]==0x0D)   //换行
       {
           break;
       }
       else
       {
           if(blank_space_flag==1)
           {
                blank_space_flag=0; 
                if(arg_num < ARG_NUM)
                {
                   index[arg_num]=i;
                    arg_num++;         
                }
                else
                {
                    return -1;      //参数个数太多
                }
           }
       }
    }
   
    for(i=0;i<arg_num;i++)
    {
        cmd_analyze.cmd_arg[i]=string_to_dec((unsigned char *)(rec_buf+index[i]),len-index[i]);
    }
    return arg_num;
}




/*打印字符串:Hello world!*/  
void printf_hello(int32_t argc, void *cmd_arg)  
{  
   UARTprintf("Hello world!\n");  
} 

/*打印每个参数*/  
void handle_arg(int32_t argc, void * cmd_arg)  
{  
   uint32_t i;  
   int32_t  *arg=(int32_t *)cmd_arg;  
     
    if(argc==0)  
    {  
       UARTprintf("no parameter.\n");  
    }  
    else  
    {  
       for(i=0;i<argc;i++)  
       {  
           UARTprintf("NO.%d:%d\n",i+1,arg[i]);  
       }  
    }  
}  


/*命令行分析任务*/  
void vTaskCmdAnalyze( void *pvParameters )  
{  
   uint32_t i;  
   int32_t rec_arg_num;  
    char cmd_buf[CMD_LEN]; //命令最长20个char       
     
	while(1)  
    {  
		uint32_t rec_num;  
		//二值信号量对应的任务通知（若命令改变，将产生通知，才能执行下面的函数体）
		ulTaskNotifyTake(pdTRUE,portMAX_DELAY); 
 //1、将命令进行格式化处理，主要是去掉一些格式符，如回车换行等	
//2、获取命令有效字符的个数len			
		rec_num=get_true_char_stream(cmd_analyze.processed_buf,cmd_analyze.rec_buf);  
		 
		/*从接收数据中提取命令*/  
		for(i=0;i<CMD_LEN;i++) //对某行命令进行提取 
		{  
			if((i>0)&&((cmd_analyze.processed_buf[i]==' ')||(cmd_analyze.processed_buf[i]==0x0D)))  
			{  
				cmd_buf[i]='\0';        //字符串结束符  
				break;  
			}  
			else  
			{  
				cmd_buf[i]=cmd_analyze.processed_buf[i];  
			}  
		}  

//		
		rec_arg_num=cmd_arg_analyze(&cmd_analyze.processed_buf[i],rec_num);  
		 
		for(i=0;i<sizeof(cmd_list)/sizeof(cmd_list[0]);i++)  
		{  
		   if(!strcmp(cmd_buf,cmd_list[i].cmd_name))       //字符串相等  
		   {  
				if(rec_arg_num<0 || rec_arg_num>cmd_list[i].max_args)  
				{  
					UARTprintf(("too many parameters!\n"));  
				}  
				else  
				{  
					cmd_list[i].handle(rec_arg_num,(void *)cmd_analyze.cmd_arg);  
				}  
				break;  
		   }  
			 
		}  
		if(i>=sizeof(cmd_list)/sizeof(cmd_list[0]))  
		{  
			UARTprintf(("unsupported instruction!\n"));  
		}  
    }  
}



#define MAX_TASK_NUM        15
TaskStatus_t pxTaskStatusArray[MAX_TASK_NUM];


/*获取OS任务信息*/  
void get_task_state(int32_t argc, void *cmd_arg)  
{  
    const char task_state[]={'r','R','B','S','D'};  
    volatile UBaseType_t uxArraySize, x;  
    uint32_t ulTotalRunTime,ulStatsAsPercentage;  
   
    /* 获取任务总数目 */  
    uxArraySize = uxTaskGetNumberOfTasks();  
   if(uxArraySize>MAX_TASK_NUM)  
    {  
        UARTprintf(("too many task！\n"));  
    }  
   
    /*获取每个任务的状态信息 */  
    uxArraySize = uxTaskGetSystemState(pxTaskStatusArray, uxArraySize, &ulTotalRunTime );  
   
    #if (configGENERATE_RUN_TIME_STATS==1)  
     
    UARTprintf("task      state   ID  priority  stack  CPU\n");  
   
    /* 避免除零错误 */  
    if( ulTotalRunTime > 0 )  
    {  
        /* 将获得的每一个任务状态信息部分的转化为程序员容易识别的字符串格式 */  
        for( x = 0; x < uxArraySize; x++ )  
        {  
            char tmp[128];  
             
            /* 计算任务运行时间与总运行时间的百分比。*/  
            ulStatsAsPercentage =(uint64_t)(pxTaskStatusArray[ x ].ulRunTimeCounter)*100 / ulTotalRunTime;  
   
            if( ulStatsAsPercentage > 0UL )  
            {  
   
               sprintf(tmp,"%-12s%-6c%-6d%-8d%-8d%d%%",pxTaskStatusArray[ x].pcTaskName,task_state[pxTaskStatusArray[ x ].eCurrentState],  
                                                                       pxTaskStatusArray[ x ].xTaskNumber,pxTaskStatusArray[ x].uxCurrentPriority,  
                                                                       pxTaskStatusArray[ x ].usStackHighWaterMark,ulStatsAsPercentage);  
            }  
            else  
            {  
                /* 任务运行时间不足总运行时间的1%*/  
                sprintf(tmp,"%-12s%-6c%-6d%-8d%-8dt<1%%",pxTaskStatusArray[x ].pcTaskName,task_state[pxTaskStatusArray[ x ].eCurrentState],  
                                                                       pxTaskStatusArray[ x ].xTaskNumber,pxTaskStatusArray[ x].uxCurrentPriority,  
                                                                       pxTaskStatusArray[ x ].usStackHighWaterMark);                 
            }  
			UARTprintf("%s\n", tmp);
        }  
    }  
    UARTprintf("task_state:   r-run  R-ready  B-block  S-suspend  D-delete\n");  
    #endif //#if (configGENERATE_RUN_TIME_STATS==1)  
}  

extern float g_humidity;
void printf_humidity(int32_t argc, void *cmd_arg){
	UARTprintf("Humidity:%f\r\n", g_humidity);
}


//extern uint8_t g_clean_time[];
void printf_clean_time(int32_t argc, void *cmd_arg){
	UARTprintf("clean_time:%d\r\n", g_clean_time[1]*256+g_clean_time[0]);
	UARTprintf("time resolution(s): %d \r\n", g_clean_time_resolution);
	UARTprintf("time max          : %d \r\n", g_clean_time_max);
}

//void printf_boost_time(int32_t argc, void *cmd_arg){
//	UARTprintf("boost_time:%d\r\n", g_boost_time);
//	UARTprintf("time resolution(s): %d \r\n", g_boost_time_resolution);
//	UARTprintf("time max          : %d \r\n", g_boost_time_max);
//}

//void printf_drying_time(int32_t argc, void *cmd_arg){
//	UARTprintf("drying_time:%d\r\n", g_drying_time);
//	UARTprintf("time resolution(s): %d \r\n", g_drying_time_resolution);
//	UARTprintf("time max          : %d \r\n", g_drying_time_max);
//}

void set_to_mode_fault(int32_t argc, void *cmd_arg){
	UARTprintf("Set to mode fault.\r\n");
	g_SystemStatus= MODE_FAULT;
}

void set_to_mode_normal(int32_t argc, void *cmd_arg){
	UARTprintf("Set to mode fault.\r\n");
	g_SystemStatus= MODE_NORMAL;
}

void set_to_mode_poweroff(int32_t argc, void *cmd_arg){
	UARTprintf("Set to mode fault.\r\n");
	g_SystemStatus= MODE_POWEROFF;
}

void set_to_mode_clean(int32_t argc, void *cmd_arg){
	UARTprintf("Set to mode fault.\r\n");
	g_SystemStatus= MODE_CLEAN;
}

void set_to_mode_drying(int32_t argc, void *cmd_arg){
	UARTprintf("Set to mode fault.\r\n");
	g_SystemStatus= MODE_DRYING;
}

void set_clean_time(int32_t argc, void * cmd_arg)  
{   
	uint8_t temp_array[2];
	int32_t  *arg=(int32_t *)cmd_arg;  
     
    if(argc==0)  
    {  
       UARTprintf("no parameter.\n");  
    }  
	else if(argc==1)
	{
		if(arg[0]>g_clean_time_max || arg[0]<0)
		{
			UARTprintf("error parameter.\r\n");
		}
		else
		{
			temp_array[CLEAN_TIME_HIGH] = (uint8_t)(arg[0]>>8);
			temp_array[CLEAN_TIME_LOW] = (uint8_t)arg[0];
			I2C_EE_BufferWrite(temp_array, CLEAN_TIME_ADDR, 2);
			I2C_EE_BufferRead(g_clean_time, CLEAN_TIME_ADDR, 2);
			UARTprintf("set up seccessfully.\r\n"); 
		}
		
	}
    else  
    {  
       UARTprintf("too many parameter.\r\n"); 
    }  
} 

void set_clean_time_max(int32_t argc, void *cmd_arg){
	int32_t  *arg=(int32_t *)cmd_arg;  
    uint8_t temp_array[2];
    if(argc==0)  
    {  
       UARTprintf("no parameter.\n");  
    }  
	else if(argc==1)
	{
		//write
		temp_array[0] = (uint8_t)(arg[0]>>8);
		temp_array[1] = (uint8_t)(arg[0]);
		I2C_EE_BufferWrite(temp_array, CLEAN_TIME_MAX_ADDR, 2);
		//read
		I2C_EE_BufferRead(temp_array, CLEAN_TIME_MAX_ADDR, 2);
		g_clean_time_max = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
		UARTprintf("set up seccessfully.\r\n"); 
	}
    else  
    {  
       UARTprintf("too many parameter.\r\n"); 
    } 
}

void set_drying_time_max(int32_t argc, void *cmd_arg){
	int32_t  *arg=(int32_t *)cmd_arg;  
    uint8_t temp_array[2];
    if(argc==0)  
    {  
       UARTprintf("no parameter.\n");  
    }  
	else if(argc==1)
	{
		//write
		temp_array[0] = (uint8_t)(arg[0]>>8);
		temp_array[1] = (uint8_t)(arg[0]);
		I2C_EE_BufferWrite(temp_array, DRYING_TIME_MAX_ADDR, 2);
		//read
		I2C_EE_BufferRead(temp_array, DRYING_TIME_MAX_ADDR, 2);
		g_drying_time_max = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
		UARTprintf("set up seccessfully.\r\n");
	}
    else  
    {  
       UARTprintf("too many parameter.\r\n"); 
    } 
}

void set_boost_time_max(int32_t argc, void *cmd_arg){
	int32_t  *arg=(int32_t *)cmd_arg;  
    uint8_t temp_array[2];
    if(argc==0)  
    {  
       UARTprintf("no parameter.\n");  
    }  
	else if(argc==1)
	{
		//write
		temp_array[0] = (uint8_t)(arg[0]>>8);
		temp_array[1] = (uint8_t)(arg[0]);
		I2C_EE_BufferWrite(temp_array, BOOST_TIME_MAX_ADDR, 2);
		//read
		I2C_EE_BufferRead(temp_array, BOOST_TIME_MAX_ADDR, 2);
		g_boost_time_max = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
		UARTprintf("set up seccessfully.\r\n");
	}
    else  
    {  
       UARTprintf("too many parameter.\r\n"); 
    } 
}

void set_clean_time_resolution(int32_t argc, void *cmd_arg){
	int32_t  *arg=(int32_t *)cmd_arg;  
    uint8_t temp_array[2];
    if(argc==0)  
    {  
       UARTprintf("no parameter.\n");  
    }  
	else if(argc==1)
	{
		//write
		temp_array[0] = (uint8_t)(arg[0]>>8);
		temp_array[1] = (uint8_t)(arg[0]);
		I2C_EE_BufferWrite(temp_array, CLEAN_TIME_RESOLUTION_ADDR, 2);
		//read
		I2C_EE_BufferRead(temp_array, CLEAN_TIME_RESOLUTION_ADDR, 2);
		g_clean_time_resolution = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
		UARTprintf("set up seccessfully.\r\n");
	}
    else  
    {  
       UARTprintf("too many parameter.\r\n"); 
    } 
}

void set_drying_time_resolution(int32_t argc, void *cmd_arg){
	int32_t  *arg=(int32_t *)cmd_arg;  
    uint8_t temp_array[2];
    if(argc==0)  
    {  
       UARTprintf("no parameter.\n");  
    }  
	else if(argc==1)
	{
		//write
		temp_array[0] = (uint8_t)(arg[0]>>8);
		temp_array[1] = (uint8_t)(arg[0]);
		I2C_EE_BufferWrite(temp_array, DRYING_TIME_RESOLUTION_ADDR, 2);
		//read
		I2C_EE_BufferRead(temp_array, DRYING_TIME_RESOLUTION_ADDR, 2);
		g_drying_time_resolution = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
		UARTprintf("set up seccessfully.\r\n");
	}
    else  
    {  
       UARTprintf("too many parameter.\r\n"); 
    } 
}

void set_boost_time_resolution(int32_t argc, void *cmd_arg){
	int32_t  *arg=(int32_t *)cmd_arg;  
    uint8_t temp_array[2];
    if(argc==0)  
    {  
       UARTprintf("no parameter.\n");  
    }  
	else if(argc==1)
	{
		//write
		temp_array[0] = (uint8_t)(arg[0]>>8);
		temp_array[1] = (uint8_t)(arg[0]);
		I2C_EE_BufferWrite(temp_array, BOOST_TIME_RESOLUTION_ADDR, 2);
		//read
		I2C_EE_BufferRead(temp_array, BOOST_TIME_RESOLUTION_ADDR, 2);
		g_boost_time_resolution = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
		UARTprintf("set up seccessfully.\r\n");
	}
    else  
    {  
       UARTprintf("too many parameter.\r\n"); 
    } 
}

void set_fan(int32_t argc, void *cmd_arg){
	int32_t  *arg=(int32_t *)cmd_arg;
	if(argc==0)  
    {  
       UARTprintf("no parameter.\n");  
    }  
	else if(argc==1)
	{
		switch (arg[0])
        {	
			case STOP:
				SetFanMode(STOP);
				UARTprintf("Change fan_speed to STOP.\r\n");
				break;
        	case LOW:
				SetFanMode(LOW);
				UARTprintf("Change fan_speed to LOW.\r\n");
        		break;
        	case MID:
				SetFanMode(MID);
				UARTprintf("Change fan_speed to MID.\r\n");
        		break;
			case HIGH:
				SetFanMode(HIGH);
				UARTprintf("Change fan_speed to HIGH.\r\n");
        		break;
			case BOOST:
				SetFanMode(BOOST);
				UARTprintf("Change fan_speed to BOOST.\r\n");
        		break;
        	default:
				UARTprintf("parameter must be between 0 and 4.\r\n");
        		break;
        }
	}
    else  
    {  
       UARTprintf("too many parameter.\r\n"); 
    } 
}

void set_mode(int32_t argc, void *cmd_arg){
	int32_t  *arg=(int32_t *)cmd_arg;  
    if(argc==0)  
    {  
       UARTprintf("no parameter.\n");  
    }  
	else if(argc==1)
	{
		switch (arg[0])
        {	
        	case 1:
				g_SystemStatus= MODE_NORMAL;
				UARTprintf("Set to mode normal.\r\n");
        		break;
        	case 2:
				g_SystemStatus= MODE_POWEROFF;
				UARTprintf("Set to mode poweroff.\r\n");
        		break;
			case 3:
				g_SystemStatus= MODE_FAULT;
				UARTprintf("Set to mode fault.\r\n");
        		break;
			case 4:
				g_SystemStatus= MODE_DRYING;
				UARTprintf("Set to mode drying.\r\n");
        		break;
			case 5:
				g_SystemStatus= MODE_CLEAN;
				UARTprintf("Set to mode clean.\r\n");
        		break;
        	default:
				UARTprintf("parameter must be between 1 and 5.\r\n");
        		break;
        }
	}
    else  
    {  
       UARTprintf("too many parameter.\r\n"); 
    } 
}

void get_all_parameter(int32_t argc, void *cmd_arg){

	UARTprintf("system state = ");
	switch(g_SystemStatus){
		case MODE_NORMAL:
			UARTprintf("mode normal\r\n");
			break;
		case MODE_POWEROFF:
			UARTprintf("mode poweroff\r\n");
			break;
		case MODE_CLEAN:
			UARTprintf("mode clean\r\n");
			break;
		case MODE_DRYING:
			UARTprintf("mode drying\r\n");
			break;
		case MODE_FAULT:
			UARTprintf("mode fault\r\n");
			break;
		case MODE_PAIR:
			UARTprintf("mode pair\r\n");
			break;
		case MODE_TEST:
			UARTprintf("mode test\r\n");
			break;
		default:
			UARTprintf("error\r\n");
			break;
	}
	UARTprintf("fan = ");
	switch (GetFanMode())
    {
    	case LOW:
			UARTprintf("LOW\r\n");
    		break;
    	case MID:
			UARTprintf("MID\r\n");
    		break;
		case HIGH:
			UARTprintf("HIGH\r\n");
    		break;
		case STOP:
			UARTprintf("STOP\r\n");
    		break;
		case BOOST:
			UARTprintf("BOOST\r\n");
    		break;
    	default:
			UARTprintf("error\r\n");
    		break;
    }
	if(g_ala_enable == 1){
		UARTprintf("Is detect alarm: ENABLE!\r\n");
	}else if(g_ala_enable == 0){
		UARTprintf("Is detect alarm: DISABLE!\r\n");
	}else{
		UARTprintf("Is detect alarm: ERROR!\r\n");
	}
	if(g_tun_enable == 1){
		UARTprintf("Is detect tungsten: ENABLE!\r\n");
	}else if(g_tun_enable == 0){
		UARTprintf("Is detect tungsten: DISABLE!\r\n");
	}else{
		UARTprintf("Is detect tungsten: ERROR!\r\n");
	}
	UARTprintf("g_app_connected          : %d\r\n", g_app_connected);
	UARTprintf("clean_time           : %d\r\n", g_clean_time[1]*256+g_clean_time[0]);
	UARTprintf("clean_time resolution(s) : %d\r\n", g_clean_time_resolution);
	UARTprintf("clean_time max           : %d\r\n", g_clean_time_max);
//	UARTprintf("drying_time          : %d\r\n", g_drying_time);
//	UARTprintf("drying_time resolution(s): %d\r\n", g_drying_time_resolution);
//	UARTprintf("drying_time max          : %d\r\n", g_drying_time_max);
//	UARTprintf("boost_time           : %d\r\n", g_boost_time);
//	UARTprintf("boost_time resolution(s) : %d\r\n", g_boost_time_resolution);
//	UARTprintf("boost_time max           : %d\r\n", g_boost_time_max);
	
}


//void switch_pm_module(int32_t argc, void *cmd_arg){
//	int32_t  *arg=(int32_t *)cmd_arg; 
//	
//	switch(arg[0]){
//		case 1:
//			SendCommand(UART_PM, (uint8_t *)&command_A4CG_DeviceOn, SIZE_COMMAND_A4CG);
//			break;
//		case 0:
//			SendCommand(UART_PM, (uint8_t *)&command_A4CG_DeviceOff, SIZE_COMMAND_A4CG);			
//			break;
//		default:
//			break;
//	}
//	
//}



void enable_alarm_detect(int32_t argc, void *cmd_arg){
	int32_t  *arg=(int32_t *)cmd_arg; 
	switch(arg[0]){
		case 1:
			g_ala_enable = 1;
			I2C_EE_BufferWrite(&g_ala_enable, ALA_ENABLE_ADDR, 1);
			UARTprintf("set alarm detect enable.\r\n");
			break;
		case 0:
			g_ala_enable = 0;
			I2C_EE_BufferWrite(&g_ala_enable, ALA_ENABLE_ADDR, 1);
			UARTprintf("set alarm detect disable.\r\n");
			break;
		default:
			break;
	}
}

void enable_tungsten_detect(int32_t argc, void *cmd_arg){
	int32_t *arg=(int32_t *)cmd_arg;
	switch(arg[0]){
		case 1:
			g_tun_enable = 1;
			I2C_EE_BufferWrite(&g_tun_enable, TUN_ENABLE_ADDR, 1);
			UARTprintf("set tungsten detect enable.\r\n");
			break;
		case 0:
			g_tun_enable = 0;
			I2C_EE_BufferWrite(&g_tun_enable, TUN_ENABLE_ADDR, 1);
			UARTprintf("set tungsten detect disable.\r\n");
			break;
		default:
			break;
	}
}

void SetLeds(int32_t argc, void *cmd_arg){
	int32_t *arg=(int32_t *)cmd_arg;
	SetLedState((uint8_t)arg[0], (uint8_t)arg[1]);
	SetLedColor((uint8_t)arg[0], (ledColor)arg[2]);
}

void AdjFan(int32_t argc, void *cmd_arg){
	int32_t  *arg=(int32_t *)cmd_arg; 
	Fan_Status *p = GetFanStatus();
	if ((arg[0] <= 100)) {
		AdjFanPWM(arg[0]);
		UARTprintf("set successfully.\r\n");
	}
	else {
		UARTprintf("parameter must be between 0 and 100.\r\n");
	}
}

///**
//  * @}
//  */
//void USART1_IRQHandler(void)
//{
//	uint8_t data;
//	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
//	{ 		
//		USART_ClearITPendingBit(USART1,USART_IT_RXNE);
//		
//		data = USART_ReceiveData(USART1);
//		USART_SendData(USART1,(uint16_t)data);//回发收到的数据
//		fill_rec_buf(data);
//	}
////	else if(USART_GetITStatus(USART1, USART_IT_TXE) != RESET)
////	{
////		//USART_ClearITPendingBit(USART1,USART_IT_TXE);
////		software_uart_transmit_interrupt_subroutine(USART1, &uart1_tx_fifo);  
////	}
//}
