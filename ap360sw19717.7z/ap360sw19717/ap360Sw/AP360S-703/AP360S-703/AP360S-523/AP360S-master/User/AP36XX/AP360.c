/*
	���ļ�����AP360Ӧ�ò㺯������������ȵ�


*/
#include "AP360.h"
#include "BSP_TIMER.h" 
#include "BSP_AP360_GPIO.h"
#include "BSP_ADC.h"
#include "BSP_SysTick.h"
#include "BSP_CH2O_N_PM25.h"
#include "BSP_EEPROM.h"
#include "filter.h"
#include "stdio.h"
#include "sw_iic.h"

#define PRINT_TEMPERATURE_N_HUMIDITY

/*==============================��������������־������====================================================================*/
/*��������������־����ʼ��*/
uint8_t g_key_power_action=0;
uint8_t g_key_mode_action=0;
uint8_t g_key_boost_action=0;

/*=================================boost ģʽ��־����====================================================================*/
uint8_t g_boost_start=0;
uint8_t g_boost_running=0;

/*=================================ϵͳģʽ�ṹ��=======================================================================*/
MODE g_SystemStatus = MODE_NORMAL;/*ϵͳģʽ�ṹ���ʼ��*/
SystemMode_Beginning_Handle g_system_mode_beginning={N_BEGINNING, N_BEGINNING, N_BEGINNING, N_BEGINNING, N_BEGINNING};

void ModeSetting(uint8_t mode){
	g_system_mode_beginning.mode_normal_beginning = N_BEGINNING;
	g_system_mode_beginning.mode_poweroff_beginning = N_BEGINNING;
	g_system_mode_beginning.mode_fault_beginning = N_BEGINNING;
	g_system_mode_beginning.mode_drying_beginning = N_BEGINNING;
	g_system_mode_beginning.mode_clean_beginning = N_BEGINNING;
	
	if(mode == SET_TO_MODE_NORMAL){
		g_SystemStatus = MODE_NORMAL;
		g_system_mode_beginning.mode_normal_beginning = BEGINNING;
	}else if(mode == SET_TO_MODE_POWEROFF){
		g_SystemStatus = MODE_POWEROFF;
		g_system_mode_beginning.mode_poweroff_beginning = BEGINNING;
	}
	else if(mode == SET_TO_MODE_FAULT){
		g_SystemStatus = MODE_FAULT;
		g_system_mode_beginning.mode_fault_beginning = BEGINNING;
	}
	else if(mode == SET_TO_MODE_DRYING){
		g_SystemStatus = MODE_DRYING;
		g_system_mode_beginning.mode_drying_beginning = BEGINNING;
	}
	else if(mode == SET_TO_MODE_CLEAN){
		g_SystemStatus = MODE_CLEAN;
		g_system_mode_beginning.mode_clean_beginning = BEGINNING;
	}
}


uint8_t ModeShutdown(void)
{
	//static uint8_t shutdown_times=0;
	
	if(g_SystemStatus == MODE_POWEROFF){
		if(g_system_mode_beginning.mode_poweroff_beginning == BEGINNING){/*??????????*/
			g_system_mode_beginning.mode_poweroff_beginning = N_BEGINNING;
			
			HIGH_VOLT_OFF();
			SetFanPwmDuty(STOP);
			ShutAllLeds();
		}
			
//		AirLinkMode();
		if(KeyScan(key_power_GPIO_Port,key_power_Pin)==KEY_SHORT_PUSH || g_key_power_action==1){
			g_key_power_action = 0;
			if(GetVoltAlarm_N_Adj()!=ALARM_SEMAPHORE)
			{
				//g_SystemStatus = MODE_NORMAL;
				ModeSetting(SET_TO_MODE_NORMAL);
				
				return 1;
			}
			else
			{	
				LED_POWER_ON();
				DelayMs(&operationTime, 200);
				LED_POWER_OFF();
			}
		}//end key power	
					
	}
	return 0;
}

uint8_t ModeNormal(void)
{
	static uint8_t normal_start_time;
	uint8_t now_time;
	if(g_SystemStatus == MODE_NORMAL){
		if(g_system_mode_beginning.mode_normal_beginning == BEGINNING){/*??????????*/
			g_system_mode_beginning.mode_normal_beginning = N_BEGINNING;//?????
			
			HIGH_VOLT_ON();
			FanMode_ADJ(&g_fan_mode, FAN_NORMAL_ADJUST ,FAN_RESUME);
			leds_control.led_power = LED_ON;
			//DelayMs(&operationTime, 2000);//����ѹ�ź��ȶ�
			normal_start_time = operationTime.second;
		}
		/*��ѹ�ȶ���ʱ�ж�*/
		now_time = operationTime.second;
		if(now_time >= normal_start_time){
			if(now_time - normal_start_time >= HIGH_VOLT_STABLE_DELAY){
				g_isHighVoltStable = HIGH_VOLT_STABLE;
			}
		}
		else{
			if(now_time + 60 - normal_start_time >= HIGH_VOLT_STABLE_DELAY){
				g_isHighVoltStable = HIGH_VOLT_STABLE;
			}
		}/* END  ��ѹ�ȶ���ʱ�ж�*/
		
		
		
		//normal_times = 0x01;//??normal_times ??????0
		if(KeyScan(key_power_GPIO_Port,key_power_Pin)==KEY_SHORT_PUSH || g_key_power_action==1){
			g_key_power_action = 0;
			//g_SystemStatus = MODE_POWEROFF;
			ModeSetting(SET_TO_MODE_POWEROFF);
			
			//normal_times = 0;
			return 1;
		}//end key power
		if(KeyScan(key_mode_GPIO_Port,key_mode_Pin)==KEY_SHORT_PUSH || g_key_mode_action==1){
			g_key_mode_action = 0;
			FanMode_ADJ(&g_fan_mode, FAN_NORMAL_ADJUST ,FAN_ADJ);
	
		}//end key mode
		if(KeyScan(key_boost_GPIO_Port,key_boost_Pin)==KEY_SHORT_PUSH || g_key_boost_action==1){
			g_key_boost_action = 0;
			FanMode_ADJ(&g_fan_mode, FAN_BOOST_ADJUST ,FAN_ADJ);
			g_boost_start=1;
		}//end key boost
			
			
	}//end mode normal
	return 0;
}
		
///*************************************************************************
/*Function: when device is in this mode, the Fan which is the only one running output 
will work 2hour in high speed. */
uint8_t ModeDrying(void)
{
	//static uint8_t drying_times=0;
	static uint16_t first_time;
	uint16_t now_time;
	if(g_SystemStatus == MODE_DRYING){
		if(g_system_mode_beginning.mode_drying_beginning == BEGINNING){/*??????????*/
			g_system_mode_beginning.mode_drying_beginning = N_BEGINNING;
			
			HIGH_VOLT_OFF();
			SetFanPwmDuty(HIGH);
			ShutAllLeds();
			
			leds_control.led_power = LED_ON;
			leds_control.led_drying = LED_ON;
			first_time = operationTime.minute;
		}
		//drying_times = 0x01;//??normal_times ??????0
		if(KeyScan(key_power_GPIO_Port,key_power_Pin)==KEY_SHORT_PUSH || g_key_power_action==1){
			g_key_power_action = 0;
			//g_SystemStatus = MODE_POWEROFF;
			ModeSetting(SET_TO_MODE_POWEROFF);
		
			return 1;
		}//end key power
		
		now_time = (uint16_t)operationTime.minute;
		if(now_time < first_time){
			now_time += 60;
		}
		if(now_time - first_time >= DRYING_TIME){
			g_key_power_action = 0;
			leds_control.led_drying = LED_OFF;
			ModeSetting(SET_TO_MODE_NORMAL);
			
		
			return 1;		
		}
		
	}
	return 0;
}	

/*************************************************************************
Function: when device is in this fault mode, the 3leds will flicker

*/
uint8_t ModeFault(void)
{
	//static uint8_t fault_times=0;
//	static uint16_t last_time=0; 
	//uint8_t now_time;
	if(g_SystemStatus == MODE_FAULT){
		if(g_system_mode_beginning.mode_fault_beginning == BEGINNING){/*??????????*/
			g_system_mode_beginning.mode_fault_beginning = N_BEGINNING;
			
			HIGH_VOLT_OFF();
			SetFanPwmDuty(STOP);
			ShutAllLeds();
			
			leds_control.led_power = LED_ON;
			leds_control.led_high = LED_ON;
			leds_control.led_mid = LED_ON;
			leds_control.led_low = LED_ON;
			//last_time = operationTime.minute;
		
		}
		//fault_times = 0x01;//??normal_times ??????0
		if(KeyScan(key_power_GPIO_Port,key_power_Pin)==KEY_SHORT_PUSH || g_key_power_action==1){
			g_key_power_action = 0;
			//g_SystemStatus = MODE_POWEROFF;
			ModeSetting(SET_TO_MODE_POWEROFF);
			
			return 1;
		}//end key power
				
		
	}
	return 0;
}
	

/*************************************************************************
Function: when device is in this clean mode, the led clean will turn on

*/
uint8_t ModeClean(void)
{
	//static uint8_t clean_times=0;
//	uint8_t zero = 0;
	if(g_SystemStatus == MODE_CLEAN){
		if(g_system_mode_beginning.mode_clean_beginning == BEGINNING){/*??????????*/
			g_system_mode_beginning.mode_clean_beginning = N_BEGINNING;
			
			HIGH_VOLT_OFF();
			SetFanPwmDuty(STOP);
			ShutAllLeds();
			
			leds_control.led_power = LED_ON;
			leds_control.led_clean = LED_ON;
	
		}
		//clean_times = 0x01;//??normal_times ??????0
		if(KeyScan(key_power_GPIO_Port,key_power_Pin)==KEY_SHORT_PUSH || g_key_power_action==1){
			g_key_power_action = 0;
			//g_SystemStatus = MODE_POWEROFF;
			//
			ModeSetting(SET_TO_MODE_POWEROFF);
			
			//clean_times = 0;//mode fault ??,????????????
			return 1;
		}//end key power
		
		if(KeyScan(key_mode_GPIO_Port,key_mode_Pin)==KEY_LONG_PUSH || g_key_mode_action==1){
			g_key_mode_action = 0;
			leds_control.led_clean = LED_OFF;
			ModeSetting(SET_TO_MODE_NORMAL);
			g_clean_time[CLEAN_TIME_HIGH] = 0;
			g_clean_time[CLEAN_TIME_LOW] = 0;
			I2C_EE_BufferWrite(g_clean_time, CLEAN_TIME_ADDR, 2);
			
			return 1;
		}//end key mode

	}
	return 0;
}

/*=================================LED ���================================================================================*/
/*led ��������ʼ��*/
Leds_Control leds_control = {LED_OFF,	LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF, 6};
/*
*	 �ָ�LED״̬  
*/
void ResumeLeds(void){
	TIM_Cmd(ADVANCE_TIM, ENABLE);
}

/*
	������LED��״̬����������
*/
void ShutAllLeds(void){
	//TIM_Cmd(ADVANCE_TIM, DISABLE);
//	LED_POWER_OFF();
//	LED_BOOST_OFF();
//	LED_HIGH_OFF();
//	LED_MID_OFF();
//	LED_LOW_OFF();
//	LED_DRYING_OFF();
//	LED_CLEAN_OFF();
	leds_control.led_power = LED_OFF;
	leds_control.led_boost = LED_OFF;
	leds_control.led_high = LED_OFF;
	leds_control.led_mid = LED_OFF;
	leds_control.led_low = LED_OFF;
	leds_control.led_clean = LED_OFF;
	leds_control.led_drying = LED_OFF;
}
/*
	�˺�������Ƶ�ʻ�Ӱ��LEDƵ��
*/
void LedsBrightnessAdj(Leds_Control *leds_control){
	static uint16_t times=0;
	times ++;
	if(times %10 ==0)// ����
	{
		if(leds_control->led_power == LED_ON) {
			LED_POWER_ON();
		}else {
			LED_POWER_OFF();
		}
		if(leds_control->led_boost == LED_ON) {
			LED_BOOST_ON();
		}else {
			LED_BOOST_OFF();
		}
		if(leds_control->led_high == LED_ON) {
			LED_HIGH_ON();
		}else {
			LED_HIGH_OFF();
		}
		if(leds_control->led_mid == LED_ON) {
			LED_MID_ON();
		}else {
			LED_MID_OFF();
		}
		if(leds_control->led_low == LED_ON) {
			LED_LOW_ON();
		}else {
			LED_LOW_OFF();
		}
		if(leds_control->led_drying == LED_ON) {
			LED_DRYING_ON();
		}else {
			LED_DRYING_OFF();
		}
		if(leds_control->led_clean == LED_ON) {
			LED_CLEAN_ON();
		}else {
			LED_CLEAN_OFF();
		}
	}
	else if(times %10 == leds_control->led_brightness) //����
	{
		LED_POWER_OFF();
		LED_BOOST_OFF();
		LED_HIGH_OFF();
		LED_MID_OFF();
		LED_LOW_OFF();
		LED_DRYING_OFF();
		LED_CLEAN_OFF();
	}
}

/*=================================Fan ���==============================================================================*/
Fan_Mode g_fan_mode = LOW;
Fan_Mode g_fan_last_mode = STOP;

void StopFun(void){
	GPIO_InitTypeDef GPIO_InitStructure;
	
	TIM_Cmd(GENERAL_TIM, DISABLE);//ֹͣʱ��
	
  GPIO_InitStructure.GPIO_Pin =  GENERAL_TIM_CH4_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_Init(GENERAL_TIM_CH4_PORT, &GPIO_InitStructure);
	digitalLo(GENERAL_TIM_CH4_PORT,GENERAL_TIM_CH4_PIN);
}

void RuningFun(void){
	GPIO_InitTypeDef GPIO_InitStructure;
	
	TIM_Cmd(GENERAL_TIM, ENABLE);
	
  GPIO_InitStructure.GPIO_Pin =  GENERAL_TIM_CH4_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_Init(GENERAL_TIM_CH4_PORT, &GPIO_InitStructure);
	digitalLo(GENERAL_TIM_CH4_PORT,GENERAL_TIM_CH4_PIN);
}

void SetFanPwmDuty(Fan_Mode fanMode)
{
	if(fanMode==STOP){
		//StopFun();
		TIM_SetCompare4(GENERAL_TIM, FAN_PWM_STOP);
	}else if(fanMode==LOW){
		//RuningFun();
		TIM_SetCompare4(GENERAL_TIM, FAN_PWM_LOW);
	}else if(fanMode==MID){
		//RuningFun();
		TIM_SetCompare4(GENERAL_TIM, FAN_PWM_MID);
	}else if(fanMode==HIGH){
		//RuningFun();
		TIM_SetCompare4(GENERAL_TIM, FAN_PWM_HIGH);
	}else if(fanMode==BOOST){
		//RuningFun();
		TIM_SetCompare4(GENERAL_TIM, FAN_PWM_BOOST);
	}	
}
/*
* @brief : �������߻ָ�����״̬
* @preme : fanMode  ����ģʽ�ṹ�����
					 boost_or_normal ����boost��������normal����
                �˲�����Ϊ FAN_BOOST_ADJUST \ FAN_NORMAL_ADJUST
					 resume_or_adj  ����Ϊ�ָ�����״̬���ߵ�������״̬
								�˲�����Ϊ FAN_RESUME \ FAN_ADJ
*/
void FanMode_ADJ(Fan_Mode * fanMode, uint8_t boost_or_normal, uint8_t resume_or_adj){
	
	//��������״̬
	if(resume_or_adj == FAN_RESUME){
		g_fan_last_mode = *fanMode;
	}else if (resume_or_adj == FAN_ADJ){
		if(boost_or_normal == FAN_BOOST_ADJUST){
			*fanMode = BOOST;
		}else if(boost_or_normal == FAN_NORMAL_ADJUST){
			if(g_fan_last_mode == HIGH) *fanMode = STOP;
			else if(g_fan_last_mode == STOP)  *fanMode = LOW;
			else if(g_fan_last_mode == LOW)  *fanMode = MID;
			else if(g_fan_last_mode == MID)  *fanMode = HIGH;
			else if(g_fan_last_mode == BOOST)  *fanMode = LOW;
			g_fan_last_mode = *fanMode;
		}
	}

	
	//���ݷ���״̬�������
	if(*fanMode == STOP){
		leds_control.led_low = LED_OFF;
		leds_control.led_mid = LED_OFF;
		leds_control.led_high = LED_OFF;
		leds_control.led_boost = LED_OFF;
		
		
		SetFanPwmDuty(STOP);
		
	}else if(*fanMode == LOW){
		leds_control.led_low = LED_ON;
		leds_control.led_mid = LED_OFF;
		leds_control.led_high = LED_OFF;
		leds_control.led_boost = LED_OFF;
		
		SetFanPwmDuty(LOW);
	}else if(*fanMode == MID){
		leds_control.led_low = LED_ON;
		leds_control.led_mid = LED_ON;
		leds_control.led_high = LED_OFF;
		leds_control.led_boost = LED_OFF;
		
		SetFanPwmDuty(MID);
	}else if(*fanMode == HIGH){
		leds_control.led_low = LED_ON;
		leds_control.led_mid = LED_ON;
		leds_control.led_high = LED_ON;
		leds_control.led_boost = LED_OFF;
		
		SetFanPwmDuty(HIGH);
	}else if(*fanMode == BOOST){
		leds_control.led_low = LED_OFF;
		leds_control.led_mid = LED_OFF;
		leds_control.led_high = LED_OFF;
		leds_control.led_boost = LED_ON;
		
		SetFanPwmDuty(BOOST);
	}
}

/*=================================��ѹ����=====================================================*/
//uint8_t high_volt_on_time;
uint8_t g_isHighVoltStable=0;
void HIGH_VOLT_ON(){
	digitalHi(high_volt_on_off_GPIO_Port,high_volt_on_off_Pin );		
}
void HIGH_VOLT_OFF(void){
	digitalLo(high_volt_on_off_GPIO_Port,high_volt_on_off_Pin );
	g_isHighVoltStable = !HIGH_VOLT_STABLE;
}


/*=================================������==============================================================================*/
float g_temperature=0;
float g_humidity=0;


float CalculateTemperature(uint16_t temperature_from_hdc1080){
	float temperature;
	temperature = (float)temperature_from_hdc1080 * 165 /65536 - 40;
	return temperature;
}

float CalculateHumidity(uint16_t humidity_from_hdc1080){
	float humidity;
	humidity = (float)humidity_from_hdc1080 /65536;
	return humidity;
}
/*
 ??????????
*/
void GetTemperatureHumidity(float *temp_f, float *humi_f){
	static uint8_t last_time=0;
	uint16_t temp, humi;
	if(operationTime.second != last_time){
		last_time = operationTime.second;
		
		ReadHDC1080_sw_iic(&temp, &humi);
		*temp_f = CalculateTemperature(temp);
		*humi_f = CalculateHumidity(humi);
		
		#ifdef PRINT_TEMPERATURE_N_HUMIDITY
		printf("Temp: %f\r\n", *temp_f);
		printf("Humi: %f\r\n", *humi_f);
		#endif
	}
}

void PrintTemperatureHumidity(void){
	uint16_t temp, humi;
	float temp_f, humi_f;
	ReadHDC1080_sw_iic(&temp, &humi);
	temp_f = CalculateTemperature(temp);
	humi_f = CalculateHumidity(humi);
	printf("Temperature: %f\r\n", temp_f);
	printf("Humidity: %g\r\n", humi_f);
}

/*
	?????PM2.5
*/	
void GetCH2O_N_PM25(void){
	static uint8_t tempTime=0;
	if(operationTime.second  != tempTime ){
		tempTime = operationTime.second;
		if(operationTime.second % 5 == 0){
			/*���fifo�е�����*/
			while(PM_RX_FIFO.fifo_not_empty_flag){ 
				uart_get_byte(UART_PM, &PM_RX_FIFO);
			}
			GetCH2O_V2(UART_PM,&PM_RX_FIFO);
		}else if(operationTime.second % 5 == 1 || operationTime.second % 5 == 2 ||
						 operationTime.second % 5 == 3 ){//???????????????PM2.5?????
			SendCommand(UART_PM, (uint8_t *)&command_get_PM25, SIZE_COMMAND_PM25);
		}else{
			/*���fifo�е�����*/
			while(PM_RX_FIFO.fifo_not_empty_flag){ //???????,fifo????????
				uart_get_byte(UART_PM, &PM_RX_FIFO);
			}
			GetPM25_V2(UART_PM,&PM_RX_FIFO);
		}
	}// get temperature & humidity
}


/*================================ADC Ӧ�ú���=========================================================================*/
/*

*/
void GetVoltDiode_N_Adj(void){
	static uint8_t times=0;
	static uint16_t volt_array[5];
	float photo_diode_volt;
	static uint16_t last_time=0;
	/*every 100 microseconds implement this code below*/
	if(operationTime.microSecond != last_time && operationTime.microSecond%99==0){
		last_time = operationTime.microSecond;
		volt_array[times++] = ADC_ConvertedValue[PhotoDiode_Subscript];
		if(times>=5){
			times = 0;
			photo_diode_volt = (float)MiddleValueFilter(volt_array, 5)/4096*3.3;
			if(photo_diode_volt > 3) // > 3.0V
			{
				leds_control.led_brightness = BRIGHTNESS_HIGHEST;
			}
			else if(photo_diode_volt > 2) // 2.0V
			{
				leds_control.led_brightness = BRIGHTNESS_HIGH;
			}
			else if(photo_diode_volt > 1.5) // 1.5V
			{
				leds_control.led_brightness = BRIGHTNESS_MID;
			}
			else
			{
				leds_control.led_brightness = BRIGHTNESS_LOW;
			}
		}
	}	
}

uint8_t GetVoltTungsten_N_Adj(void){
	static uint8_t times=0;
	static uint16_t volt_array_a[5];
	static uint16_t volt_array_b[5];
	float tungsten_a_volt;
	float tungsten_b_volt;
	static uint16_t last_time=0;
	uint8_t return_value=0;
	
	//if(!(g_SystemStatus == MODE_NORMAL && g_isHighVoltStable == HIGH_VOLT_STABLE)) return 0;//normal״̬�¸�ѹ����Ŵ򿪣��������������˿
	
	/*every 100 microseconds implement this code below*/
	if(operationTime.microSecond != last_time && operationTime.microSecond%99==0){
		last_time = operationTime.microSecond;
		volt_array_a[times] = ADC_ConvertedValue[Tungsten_A_Subscript];
		volt_array_b[times] = ADC_ConvertedValue[Tungsten_B_Subscript];
		times++;
		if(times>=5){
			times = 0;
			tungsten_a_volt = (float)MiddleValueFilter(volt_array_a, 5)/4096*3.3;
			tungsten_b_volt = (float)MiddleValueFilter(volt_array_b, 5)/4096*3.3;
			if(tungsten_a_volt < TUNGSTEN_VOLT_LOWER_LIMIT  ){
				
				ModeSetting(SET_TO_MODE_FAULT);
				return_value |= TUNGSTEN_A_BREAK;
			}
			if(tungsten_b_volt < TUNGSTEN_VOLT_LOWER_LIMIT ){
				
				ModeSetting(SET_TO_MODE_FAULT);
				return_value |= TUNGSTEN_B_BREAK;
			}
		}
	}
	g_tungsten_break = return_value;
	return return_value;
}

/*

*/
uint8_t GetVoltAlarm_N_Adj(void){
//	static uint8_t times=0;
//	static uint16_t volt_array[5];
	float alarm_volt;
	static uint16_t last_time=0;
	
	//if(g_SystemStatus != MODE_NORMAL || g_isHighVoltStable != HIGH_VOLT_STABLE) return 0; //normal״̬�¸�ѹ����Ŵ򿪣������������ALARM�ź�
	
	/*every 20 microseconds implement this code below*/
	if(operationTime.microSecond != last_time && operationTime.microSecond%19==0){
		last_time = operationTime.microSecond;
		alarm_volt = (float)ADC_ConvertedValue[HighVolt_Alarm_Subscript]/4096*3.3;



		if(alarm_volt>ALARM_VOLT_UPPER_LIMIT || alarm_volt<ALARM_VOLT_LOWER_LIMIT){
			//g_SystemStatus = MODE_FAULT;
			ModeSetting(SET_TO_MODE_FAULT);
			return ALARM_SEMAPHORE;
		}
	}
		
	return 0;
}

/*===============================  Cleanģʽʱ���ۻ�  =================================================*/
//uint16_t ACC_running_timer; //����ϵͳ�ۻ�����ʱ��

void GetArtFromEEPROM(void){
}
void ART_ADJ(void){

}



/*===============================  ����  =============================================================================*/
uint8_t g_fault_code=0;
uint8_t g_tungsten_break=0;
uint8_t g_alarm=0;
uint8_t g_clean_time[2] = {0, 0};

/*
void AirLinkMode(void){
//	uint8_t i;
	if(KeyScan(key_mode_GPIO_Port,key_mode_Pin)==KEY_LONG_PUSH){
		//AirLink mode
		printf("KEY_MODE PRESS LONG ,AirLink mode\n");
		gizwitsSetMode(WIFI_AIRLINK_MODE);
		leds_control.led_high = LED_ON;
		leds_control.led_mid = LED_ON;
		leds_control.led_low = LED_ON;
//		for(i=0; i<30; i++){
//			leds_control.led_high = LED_ON;
//			DelayMs(&operationTime, 200);
//			leds_control.led_high = LED_OFF;
//			DelayMs(&operationTime, 500);
//		}				
	}//enter linker mode	
}
*/

void BoostMode_CountDown(void){
	static uint16_t start_time;
	uint16_t now_time;
	uint16_t duration;
	if(g_boost_start == 1){
		g_boost_start = 0;
		g_boost_running =1;
		start_time = (uint16_t)operationTime.minute * 60 + operationTime.second;
	}//end g_boost_start
	if(g_boost_running==1){
		now_time = (uint16_t)operationTime.minute * 60 + operationTime.second;
		if(now_time >= start_time) duration = now_time - start_time;
		else duration = 3600 + now_time - start_time;
		
		if(duration >= BOOST_TIME){//1200s ?20??
			//stop boost ,resume fan normal mode
			g_boost_running=0;
			
			//??????????
			if(g_fan_last_mode == STOP){
				leds_control.led_low = LED_OFF;
				leds_control.led_mid = LED_OFF;
				leds_control.led_high = LED_OFF;
				leds_control.led_boost = LED_OFF;
				
				SetFanPwmDuty(STOP);
				
			}else if(g_fan_last_mode == LOW){
				leds_control.led_low = LED_ON;
				leds_control.led_mid = LED_OFF;
				leds_control.led_high = LED_OFF;
				leds_control.led_boost = LED_OFF;
				
				SetFanPwmDuty(LOW);
			}else if(g_fan_last_mode == MID){
				leds_control.led_low = LED_ON;
				leds_control.led_mid = LED_ON;
				leds_control.led_high = LED_OFF;
				leds_control.led_boost = LED_OFF;
				
				SetFanPwmDuty(MID);
			}else if(g_fan_last_mode == HIGH){
				leds_control.led_low = LED_ON;
				leds_control.led_mid = LED_ON;
				leds_control.led_high = LED_ON;
				leds_control.led_boost = LED_OFF;
				
				SetFanPwmDuty(HIGH);
			}else if(g_fan_last_mode == BOOST){
				leds_control.led_low = LED_OFF;
				leds_control.led_mid = LED_OFF;
				leds_control.led_high = LED_OFF;
				leds_control.led_boost = LED_ON;
				
				SetFanPwmDuty(BOOST);
			}
			
		}
	}//end g_boost_running
}

void ModeFaultHandle(uint8_t fault_code){
	static uint16_t acc=0;
	acc++;
	if(acc>=1000) acc=0;
	
	if(g_SystemStatus == MODE_FAULT){	
		if(acc < 500){
			switch(fault_code){
				case TUNGSTEN_A_BREAK:
					leds_control.led_high = LED_OFF;
					leds_control.led_mid = LED_OFF;
					leds_control.led_low = LED_ON;
					break;
				case TUNGSTEN_B_BREAK:
					leds_control.led_high = LED_ON;
					leds_control.led_mid = LED_OFF;
					leds_control.led_low = LED_OFF;
					break;
				case TUNGSTEN_AB_BREAK:
					leds_control.led_high = LED_ON;
					leds_control.led_mid = LED_OFF;
					leds_control.led_low = LED_ON;
					break;
				case ALARM_SEMAPHORE:
					leds_control.led_high = LED_OFF;
					leds_control.led_mid = LED_ON;
					leds_control.led_low = LED_OFF;
					break;
				default:
					leds_control.led_high = LED_ON;
					leds_control.led_mid = LED_ON;
					leds_control.led_low = LED_ON;
					break;
			}
		
		}else{
			leds_control.led_high = LED_OFF;
			leds_control.led_mid = LED_OFF;
			leds_control.led_low = LED_OFF;
		}
	}	
}

uint8_t CleanTimeCountHandle(void){
	static uint8_t tempTime=0;
	static uint8_t tempSecond=0;
	
	/*ÿ�����ж�һ��*/
	if(operationTime.second  != tempSecond){
		tempSecond = operationTime.second;
		I2C_EE_BufferRead(g_clean_time, CLEAN_TIME_ADDR, 2);
		/*ʱ���ۼƳ�����ֵ������cleanģʽ*/
		if(g_clean_time[CLEAN_TIME_HIGH]*256 + g_clean_time[CLEAN_TIME_LOW] >= CLAEN_TIME_MAX){
			ModeSetting(SET_TO_MODE_CLEAN);
		}	
	}
	
	/*ÿ����ִ��һ���ۼ�*/
	if(operationTime.minute  != tempTime ){
		tempTime = operationTime.minute;
		/*����ģʽ�²Ż��и�ѹ���������ģʽ���ۼ�CLEAN TIME*/
		if(g_SystemStatus != MODE_NORMAL) 
			return 0;
		
		I2C_EE_BufferRead(g_clean_time, CLEAN_TIME_ADDR, 2);
		if(g_clean_time[CLEAN_TIME_LOW]==0xff){
			g_clean_time[CLEAN_TIME_LOW] = 0;
			g_clean_time[CLEAN_TIME_HIGH] ++;
		}else{
			g_clean_time[CLEAN_TIME_LOW]++;
		}
		I2C_EE_BufferWrite(g_clean_time, CLEAN_TIME_ADDR, 2);
		
//		if(g_clean_time[CLEAN_TIME_HIGH]*256 + g_clean_time[CLEAN_TIME_LOW] >= CLAEN_TIME_MAX){
//			ModeSetting(SET_TO_MODE_CLEAN);
//		}			
	}
	
	return 1;
}

